"""Reconstruct physical multipliers and spectral floors, then run the integer interval proof."""
from pathlib import Path
from tempfile import TemporaryDirectory
from functools import lru_cache
from math import comb
import json
import os
import subprocess
import sympy as sp
from sympy.physics.wigner import wigner_6j, clebsch_gordan

HERE = Path(__file__).resolve().parent
R = sp.Rational
CASES = [(5,2),(5,3),(5,4),(6,3),(6,4),(6,5),(7,4),(7,5),(7,6),(8,4),(8,7),(9,8),(10,9),(11,10)]

@lru_cache(None)
def multiplier(n,k,l):
    return sum(sp.rf(-l,i)*sp.rf(l+1,i)*sp.rf(-k,i)*sp.rf(k+1,i) /
               (sp.rf(-n,i)*sp.rf(n+2,i)*sp.factorial(i)**2) for i in range(min(l,k)+1))

@lru_cache(None)
def physical_column(n, name, q):
    # Covariant channels from spin n/2 to 2, optionally followed by positive maps.
    assert 0 <= q <= 4
    flip = name.startswith('T')
    name = name[1:] if flip else name
    assert name in ('G','globalBH','BH1','BH2','BH3')
    coefficients = {'BH1': (R(2,3),R(0)), 'BH2': (R(18,25),R(2,25)),
                    'BH3': (R(484,625),R(6,625))}
    j = R(n,2)
    b = j-2
    g = []
    for l in range(1,5):
        v = (-1)**q*wigner_6j(2,2,l,j,j,b+q)/wigner_6j(2,2,l,j,j,b)
        if name == 'globalBH':
            assert n%2
            v *= 0 if l%2 else -R(2,n-1)
        elif name in coefficients:
            a,d = coefficients[name]
            v *= (-1-(-1)**l*(a*multiplier(4,1,l)+d*multiplier(4,3,l)))/(4-a-d)
        if flip: v *= (-1)**l
        v=sp.simplify(v)
        assert v.is_Rational
        g.append(v)
    return g

def verify_adjoint_purity():
    # T=R_{5,4} Phi_2. Row-major superoperator for real Kraus matrices.
    j=R(5,2)
    channel=sp.zeros(36)
    for q in range(-2,3):
        a=sp.zeros(6)
        for col in range(6):
            row=col-q
            if 0<=row<6:
                a[row,col]=clebsch_gordan(j,2,j,j-col,q,j-row)
        channel+=sp.kronecker_product(a,a)
    reduction=sp.zeros(25,36)
    for bit in (0,1):
        a=sp.zeros(5,6)
        for row in range(5): a[row,row+bit]=sp.sqrt(R(comb(4,row),comb(5,row+bit)))
        reduction+=sp.kronecker_product(a,a)
    E=(reduction*channel).T
    # The two-copy observable is invariant. One highest-weight vector per
    # even total spin computes its scalar on the symmetric square.
    values=[]
    for spin in (0,2,4):
        highest=[(i,4-spin-i,clebsch_gordan(2,2,spin,2-i,2-(4-spin-i),spin))
                 for i in range(5-spin)]
        values.append(sp.simplify(sum(w*y*sum(E[6*a+b,5*i+p]*E[6*b+a,5*k+r]
                                       for a in range(6) for b in range(6))
                                      for i,k,w in highest for p,r,y in highest)))
    assert values == [-R(21,625),R(7446,30625),R(13781,30625)]
    assert max(values)<(R(6,5)-R(3,80))**2/3+3*R(1,80)**2

def geometry():
    weights=json.loads((HERE/'weights.json').read_text())
    assert set(weights)=={f'{n},{k}' for n,k in CASES}
    rows=[]
    for n,k in CASES:
        f=[multiplier(n,k,l) for l in range(1,5)]
        floors=set()
        for mixture in weights[f'{n},{k}']:
            total=0
            residual=f.copy()
            for (label,q),raw in mixture:
                w=R(raw)
                assert w>=0
                total+=w
                g=physical_column(n,label,q)
                residual=[a-w*b for a,b in zip(residual,g)]
            floors.add(((1-total)/5,*[-abs(x) for x in residual]))
        rows.append(f'{n} {k} {len(floors)}')
        rows.append(' '.join(map(str,f)))
        rows.extend(' '.join(map(str,row)) for row in sorted(floors))
    return '\n'.join(rows)+'\n'

if __name__=='__main__':
    verify_adjoint_purity()
    data=geometry()
    with TemporaryDirectory() as folder:
        binary=Path(folder)/'verify'
        subprocess.run([os.environ.get('CXX','c++'),'-std=c++17','-O2',
                        str(HERE/'verify.cpp'),'-o',str(binary)],check=True)
        subprocess.run([str(binary)],input=data,text=True,check=True)
