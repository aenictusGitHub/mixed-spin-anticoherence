// Integer interval arithmetic. Endpoints are multiples of 2^-40.
// Every division and square root is rounded outwards by integer comparisons.
#pragma once
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <limits>
#include <string>

using Integer = std::int64_t;
using Wide = __int128_t;
constexpr Integer unit = Integer(1) << 40;
inline Integer checked(Wide a) {
    assert(a >= std::numeric_limits<Integer>::min() && a <= std::numeric_limits<Integer>::max());
    return static_cast<Integer>(a);
}
inline Integer floor_div(Wide a, Integer b) {
    assert(b > 0);
    return checked(a / b - (a % b < 0));
}
inline Integer ceil_div(Wide a, Integer b) {
    return -floor_div(-a, b);
}
struct Interval {
    Integer l, h;
    Interval(Integer n=0) : l(checked(Wide(n)*unit)), h(l) {}
    static Interval raw(Integer a, Integer b) {
        assert(a<=b); Interval v; v.l=a; v.h=b; return v;
    }
};
using I=Interval;
inline I rat(Integer a,Integer b){return I::raw(floor_div(Wide(a)*unit,b),ceil_div(Wide(a)*unit,b));}
inline I read_rational(const std::string& s){
    auto pos=s.find('/');
    return pos==std::string::npos ? I(std::stoll(s)) : rat(std::stoll(s.substr(0,pos)),std::stoll(s.substr(pos+1)));
}
inline I operator+(I a,I b){return I::raw(checked(Wide(a.l)+b.l),checked(Wide(a.h)+b.h));}
inline I operator-(I a,I b){return I::raw(checked(Wide(a.l)-b.h),checked(Wide(a.h)-b.l));}
inline I operator*(I a,I b){
    Wide p=Wide(a.l)*b.l,q=Wide(a.h)*b.h,r=Wide(a.h)*b.l,s=Wide(a.l)*b.h;
    return I::raw(floor_div(std::min({p,q,r,s}),unit),ceil_div(std::max({p,q,r,s}),unit));
}
inline I operator/(I a,I b){
    assert(b.l>0);
    return I::raw(floor_div(Wide(a.l)*unit,a.l<0?b.l:b.h),ceil_div(Wide(a.h)*unit,a.h<0?b.h:b.l));
}
inline I imin(I a,I b){return I::raw(std::min(a.l,b.l),std::min(a.h,b.h));}
inline I imax(I a,I b){return I::raw(std::max(a.l,b.l),std::max(a.h,b.h));}
inline bool greater(I a,I b){return a.l>b.h;}
inline I square(I a){return a.l>=0 || a.h<=0?a*a:I::raw(0,(a*a).h);}
inline Integer isqrt(Wide x){
    assert(x>=0);
    Integer r=static_cast<Integer>(std::sqrt(static_cast<long double>(x)));
    while(Wide(r)*r>x)--r;
    while(Wide(r+1)*(r+1)<=x)++r;
    return r;
}
inline I root(I a){ // sqrt(max(0,x))
    Wide hi=Wide(std::max(Integer(0),a.h))*unit;
    Integer b=isqrt(hi);
    return I::raw(isqrt(Wide(std::max(Integer(0),a.l))*unit),b+(Wide(b)*b<hi));
}
inline I lower(I a){return I::raw(a.l,a.l);}
inline I upper(I a){return I::raw(a.h,a.h);}
