#include "interval.hpp"
#include <array>
#include <iostream>
#include <vector>
using Vec=std::array<I,4>;
using Index=std::array<Integer,4>;
using Floor=std::array<I,5>;
const Vec c2={rat(2,5),rat(2,7),rat(1,2),rat(18,35)};
const I target=rat(1,100);
struct Box {
    Vec lo,hi,vlo,vhi;
    I variance_lo,variance_hi,output_hi;
};
struct Certificate {
    int n,k;
    Vec f2;
    I max_f2;
    std::vector<Floor> floors;
    std::vector<std::vector<Floor>> angular;
    std::vector<std::pair<I,I>> spin_probes;
    std::uint64_t nodes=0, leaves=0;

    bool empty(const Box& b,I scale) const {
        // Necessary spin-two moment bounds, also applied to (sigma-u I)/(1-5u).
        const auto& a=b.lo; const auto& A=b.hi;
        const auto& v=b.vlo; const auto& V=b.vhi; I h=scale,H=square(h);
        return greater(8*v[1]+5*v[2]+v[3],rat(14,5)*H)
            || greater(5*v[0]+4*v[3]-3*V[1],rat(6,5)*H)
            || greater(v[0]+v[2]-V[1]-V[3],rat(1,5)*H)
            || greater(7*v[0]+3*v[1]-8*V[2]-4*V[3],rat(14,5)*H)
            || greater(25*square(a[0]),2*H+7*A[1]*h)
            || greater(15*a[0],5*h+2*root(5)*A[2])
            || greater(245*square(a[1]),14*H+(15*A[1]+20*A[3])*h)
            || greater(b.variance_lo,rat(4,5)*H);
    }
    I output_floor(const Box& b,const std::vector<Floor>& coeffs) const {
        I m=0;
        for(const auto& row:coeffs){
            I v=row[0];
            for(int j=0;j<4;j++)v=v+row[j+1]*b.hi[j];
            m=imax(m,v);
        }
        return lower(imin(m,rat(19,100)));
    }
    I max_trace_root(I variance,I u) const {
        // Upper envelope with a known upper bound u on the smallest eigenvalue.
        I cap=(1-(rat(1,5)+root(rat(4,5)*variance)))/4;
        u=imin(u,imax(0,cap));
        I total=1-u;
        I a=imin(total,(total+root(3*(4*(rat(1,5)+variance-square(u))-square(total))))/4);
        return root(u)+root(a)+root(3*(total-a));
    }
    I min_trace_root(I m,I variance) const {
        // Lower envelope with eigenvalue floor m and variance at most variance.
        I t=1-5*m,P=rat(1,5)+variance/square(t),bound=5;
        // When rounding overlaps a rank transition, enclose both branches.
        for(int n=1;n<=5;n++){
            if(greater(rat(1,n),P) || (n>1&&greater(P,rat(1,n-1))))continue;
            if(n==1){bound=imin(bound,4*root(m)+root(1-4*m));continue;}
            I d=root((n*P-1)/(n-1));
            I small=imax(0,(1-(n-1)*d)/n);
            bound=imin(bound,(5-n)*root(m)+root(m+t*small)+(n-1)*root(m+t*(1+d)/n));
        }
        assert(bound.l<5*unit);
        return lower(bound);
    }
    bool certify(const Index& low,const Index& high,int depth){
        nodes++;
        Box b{};
        for(int i=0;i<4;i++){
            b.lo[i]=c2[i]*I::raw(low[i],low[i]); b.hi[i]=c2[i]*I::raw(high[i],high[i]);
            b.vlo[i]=square(b.lo[i])/c2[i]; b.vhi[i]=square(b.hi[i])/c2[i];
            b.variance_lo=b.variance_lo+b.vlo[i]; b.variance_hi=b.variance_hi+b.vhi[i];
            b.output_hi=b.output_hi+f2[i]*b.vhi[i];
        }
        if(empty(b,1)){leaves++;return true;}
        I m=output_floor(b,floors), factor=root(5)/(2*square(1/root(5)+root(m)));
        I input_factor=2/root(5)-target, linear=0;
        for(int i=0;i<4;i++){
            I d=input_factor-factor*f2[i];
            linear=linear+imin(d*b.vlo[i],d*b.vhi[i]);
        }
        if(greater(input_factor,factor*max_f2)||linear.l>=0){leaves++;return true;}
        I v=lower(imin(rat(4,5),b.variance_lo)),o=upper(b.output_hi);
        I in=upper(max_trace_root(v,rat(1,5)));
        for(auto [x,tr]:spin_probes)
            in=imin(in,root((1-x*rat(5,2)*b.lo[0])*tr));
        I margin=target*b.variance_hi;
        if(greater(min_trace_root(m,o),in+margin)){leaves++;return true;}
        if(n==5 && k==2 && depth>=11){
            I common=rat(1,5);
            for(const auto& fs:angular){
                common=imin(common,output_floor(b,fs));
                if(common.h<=m.l)break;
            }
            m=lower(imax(m,common));
            if(greater(min_trace_root(m,o),in+margin)){leaves++;return true;}
            if(depth>=15){
                bool all=true;
                for(int j=0;j<400;j++){
                    I u=rat(j,2000),U=rat(j+1,2000);
                    if(empty(b,1-5*u))continue;
                    I out=min_trace_root(lower(imax(m,u/80)),o);
                    I upper_in=imin(in,max_trace_root(v,U));
                    if(!greater(out,upper_in+margin)){all=false;break;}
                }
                if(all){leaves++;return true;}
            }
        }
        int axis=0;
        for(int i=1;i<4;i++)if(high[i]-low[i]>high[axis]-low[axis])axis=i;
        if(high[axis]-low[axis]<=1){std::cerr<<"Unresolved box\n";return false;}
        Index left=high,right=low;left[axis]=right[axis]=(low[axis]+high[axis])/2;
        return certify(low,left,depth+1)&&certify(right,high,depth+1);
    }
    void prepare(){
        for(int i:{10,20,30,40,50,60,70,75,80,85,90,94,97,99,100}){
            I x=i==100?rat(999,1000):rat(i,100);
            spin_probes.emplace_back(x,1+2/(1-square(x))+2/(1-square(x)/4));
        }
        if(n!=5||k!=2)return;
        // Cover (n1, time-reversal overlap) by sixteen rectangles.
        for(int i=0;i<4;i++)for(int j=0;j<4;j++){
            I x=rat(i,10),X=rat(i+1,10),s=rat(j,4),S=rat(j+1,4);
            if(greater(x,(1-s)/2))continue;
            Vec cap={imin(X,(1-s)/2),imin(rat(2,7),(5*X+2*S)/7),
                     imin(rat(1,2),(1-s)/2-x),imin(rat(18,35),rat(3,10)+3*S/14-5*x/7)};
            bool impossible=false;for(I a:cap)impossible|=(a.h<0);
            if(impossible)continue;
            auto fs=floors;
            for(auto& f:fs)for(int l=0;l<4;l++)f[l+1]=f[l+1]*root(cap[l]/c2[l]);
            angular.push_back(fs);
        }
    }
};
int main(){
    int n,k,b;
    while(std::cin>>n>>k>>b){
        Certificate c{};c.n=n;c.k=k;
        std::string s;
        for(I& f:c.f2){std::cin>>s;f=square(read_rational(s));c.max_f2=imax(c.max_f2,f);}
        for(int i=0;i<b;i++){
            Floor row;for(I& x:row){std::cin>>s;x=read_rational(s);}
            c.floors.push_back(row);
        }
        assert(std::cin.good());c.prepare();
        if(!c.certify(Index{},Index{unit,unit,unit,unit},0))return 1;
        std::cout<<n<<" "<<k<<"  "<<c.leaves<<" verified leaves, "<<c.nodes<<" nodes"<<std::endl;
    }
}
