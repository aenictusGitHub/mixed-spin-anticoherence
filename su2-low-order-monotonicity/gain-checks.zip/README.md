# An order-four comparison of fidelity and von Neumann entropy gains

Let R be the reduction of a symmetric N-qubit state to the five-dimensional symmetric sector of four qubits. Write σ=Rρ, τ=RΦρ, T(X)=Tr√X, S(X)=−Tr X log X in natural units, and V(X)=Tr(X−I/5)². For every N≥4, every SU(2)-covariant CPTP channel on spin N/2 and every density matrix ρ, the comparison is

    T(τ) − T(σ) ≥ [S(τ) − S(σ)]/500.

The calculation uses channel geometry and spin-two inequalities in the accompanying project's [low-order proof](https://github.com/aenictusGitHub/mixed-spin-anticoherence/blob/main/su2-low-order-monotonicity/proof.tex). The verifier uses physical multipliers, positive maps and spectral inequalities. The sign of the entropy gain enters when drawing the converse as a corollary.

## Reproduction

Run `python3 verify.py` from the unpacked directory, with Python 3, SymPy, and a C++17 compiler (Clang or GCC with signed 128-bit integer support). Set CXX if necessary. The driver reconstructs each rational coefficient, checks the new two-copy calculation, compiles the interval verifier in a temporary directory, and checks a complete covering of the fourteen base domains. No solver or random seed enters verification. Keep compiler assertions enabled. Output from the verified run is in verification.txt.

The JSON file gives only nonnegative rational weights and physical map identifiers. The target and all auxiliary multipliers, every residual and every spectral floor are recomputed. An arbitrary list of such nonnegative weights is valid for bounding the output, although a poor choice can leave boxes unresolved.

## Reduction to a finite inequality

The project's order-four convex decompositions use positive unital trace-preserving maps on the spin-two marginal, spin reversal, and fourteen base maps with an available symmetric extension. Their labels (N,K) are listed in verify.py. The hull and availability theorem are used as proved in the linked source, lines 1522–1746. For each base map the finite inequality established here is

    T(τ) − T(σ) ≥ V(σ)/100.                                          (1)

Since S(τ)−S(σ) ≤ log 5−S(σ) ≤ 5 V(σ) by log x ≤ x−1, (1) implies monotonicity of J=T−S/500 on those maps. The function x ↦ √x + x log(x)/500 is concave on [0,1], with its continuous value at zero. J is thus concave on density matrices, and increases under majorization towards a more mixed state. This covers the local positive unital trace-preserving maps. Spin reversal is isospectral. Concavity proves the same statement for their convex mixtures and those involving base maps. Reduction to each available smaller spin preserves the common four-body marginal. For N=4 the full channel is unital, so majorization suffices directly.

## Coordinates and input constraints

Write σ=I/5+Σ X_l, with tensor ranks l=1,…,4, v_l=Tr X_l² and a_l=c_l√v_l. The squared operator norm constants c_l² are (2/5,2/7,1/2,18/35). The target is τ=I/5+Σ f_l X_l. Hence V(σ)=Σv_l and V(τ)=Σf_l²v_l. Since v_l=Tr(σ X_l)≤c_l√v_l, the initial box is 0≤a_l≤c_l². The necessary linear and quadratic bounds on v and a used by the function empty are the seven inequalities at lines 1906–1933 of the project proof, plus the unit purity bound. To test λ_min(σ)≥u with u<1/5, apply them also to (σ−uI)/(1−5u).

The auxiliary positive images η_j=I/5+Σg_jl X_l used in weights.json are the rectangular Clebsch–Gordan channels and their compositions with the positive maps proved at lines 2379–2462. For any chosen weights w_j≥0, write h_l=f_l−Σw_j g_jl. Then

    λ_min(τ) ≥ (1−Σw_j)/5 − Σ |h_l| a_l.                             (2)

For the (5,2) base map we strengthen this estimate. For a pure output test vector v let n_l=‖P_l(|v⟩⟨v|)‖₂², x=n_1 and s=|⟨v|Θv⟩|², where Θ on vectors denotes time reversal. By the spin-two two-copy identity in the project proof, and time-reversal parity,

    n_2=(5x+2s)/7,  n_3=(1−s)/2−x,  n_4=3/10+3s/14−5x/7.

Also 0≤n_l≤c_l². In the expectation of τ on v, replace each a_l in (2) by √(n_l v_l), by Hilbert–Schmidt Cauchy–Schwarz. Split [0,2/5]×[0,1] for x,s into 4×4 rectangles, using the separate upper bounds on n_l in each rectangle. Maximize over the available floor estimates on each rectangle, then minimize over all nonexcluded rectangles. This is a uniform lower eigenvalue bound.

## Linking the two smallest eigenvalues for (5,2)

For this paragraph let L=RΦ₂ from spin 5/2 to spin 2. For any rank-one projector P_v set B_v=L*(P_v). It is positive with trace 6/5. The invariant two-copy observable for Tr B_v² has eigenvalues −21/625, 7446/30625 and 13781/30625 on the symmetric total-spin subspaces J=0,2,4. The driver computes these exactly by contracting the Kraus superoperator with a highest-weight vector in each subspace. Explicitly, for the adjoint superoperator E_(ab,ip), the two-copy kernel has entries Σ_ab E_(ab,ip) E_(ba,kr) at row (i,k), column (p,r), up to conjugation of the tested vector. The matrices are real, and covariance makes each total-spin block scalar. This proves Tr B_v²≤13781/30625.

If the fourth largest eigenvalue of B_v were ≤1/80, its bottom three would have sum b≤3/80. Cauchy–Schwarz gives Tr B_v²≥[(6/5−b)²+b²]/3, decreasing on that interval. At its right endpoint the lower bound exceeds the proved upper bound by 3707/3920000. Thus B_v ≥ P_U/80 for the projector onto its leading four-dimensional eigenspace U.

The complementary two-dimensional subspace U^perp has at most four-dimensional support after the two Kraus operators of R are applied. Choose a unit vector w on spin 2 orthogonal to that support. Then R*(P_w) annihilates U^perp and satisfies 0≤R*(P_w)≤I. Thus R*(P_w)≤P_U. For any full input state this gives ⟨v|τ|v⟩ ≥ ⟨w|σ|w⟩/80. Minimizing over v proves

    λ_min(τ) ≥ λ_min(σ)/80.                                          (3)

## Spectral estimates in five dimensions

Set H(X)=√5−T(X). For any spectrum p,

    H=(√5/2) Σ_i (p_i−1/5)²/(√p_i+1/√5)².

In particular H≤(√5/2)V/(√m+1/√5)² for a state of minimum eigenvalue at least m. A global lower bound is H≥(2/√5)V. To prove it minimize H−(2/√5)V. Moving mass to a zero coordinate lowers the objective by order √ε, so a minimizer is interior. The derivative of the scalar summand increases and then decreases. At a nonuniform minimizer there are two coordinate values and the larger one occurs only once (an opposite variation of two large coordinates has negative curvature). On (a,b,b,b,b), b=(1−a)/4, y=√(a/b), the derivative dH/dV equals (y²+4)^(3/2)/[4y(y+1)]. Use y²+4≥4y and √(y²+4)≥2(y+1)/√5, then integrate from the uniform state. These bounds certify a box whenever the resulting linear inequality in the v_l proves (1), including at V=0.

The remaining tests bound T(τ) below and T(σ) above. For an output floor m and variance upper bound v, put t=1−5m and P=1/5+v/t². If P≥1 the floor-simplex vertex gives the minimum. Otherwise let n=ceil(1/P), d=√[(nP−1)/(n−1)]. A minimizing spectrum has 5−n entries m, one entry m+t[1−(n−1)d]/n and n−1 entries m+t(1+d)/n. To see this, minimize on the smallest floor face carrying a minimizer. A nontrivial minimizer has active purity (strict concavity allows a decreasing variation if the constraint is slack). Lagrange multipliers give at most two different free entries, because 1/(2√x) is strictly convex. At the smaller value, the curvature of the Lagrangian is negative, so two coordinates at that value are impossible by opposite variations. All-equal free coordinates give the adjoining rank transitions. Sum and purity then give the formula above, including m=0 by continuity.

For a lower bound V on input variance, T is maximized by one large eigenvalue and the others equal. The same stationarity argument excludes a repeated larger value at a maximum. A zero coordinate can be increased by ε with an order-√ε gain in T, while restoring the sum and purity through two positive coordinates costs order ε in T. When all positive coordinates are equal, their compensating difference is order √ε and its cost in T is still order ε. The pure endpoint follows by continuity. The one-large maximum decreases with variance.

A refined upper bound also uses an upper bound U on the smallest input eigenvalue. Cap U at the equal smaller eigenvalue of the unrestricted one-large extremizer at V. With the smallest eigenvalue fixed at u, the remaining four have total t=1−u and squared sum at least V+1/5−u². Their trace-root sum is at most √a+√[3(t−a)], where a=(t+√max(0,3[4(V+1/5−u²)−t²]))/4, capped at t if needed. The resulting upper bound including √u is nondecreasing in u up to the stated cap: in the active-purity regime its derivative is g'(u) minus the linear extrapolation from g'(a),g'(b), with g(x)=√x and b=(t−a)/3. Convexity of g' gives a nonnegative difference for u≤b. In the equal-four regime this follows by differentiating √u+2√(1−u). Evaluating at the capped U therefore gives a valid upper bound for all u≤U.

For another input bound rotate the mean spin to z, put D=J_z/2, and note Tr(σD)=5a_1/2. Hilbert–Schmidt Cauchy–Schwarz with I−xD, 0<x<1, gives T(σ)²≤(1−5xa_1/2)[1+2/(1−x²)+2/(1−x²/4)]. Each x used in the verifier gives an independently valid bound.

## Coverage and exactness

For each box the verifier first tries the physical exclusions and the linear variance comparison. It otherwise uses the above spectral envelopes, taking a lower output floor, an upper output variance, and a lower input variance. For the exceptional case it can additionally subdivide λ_min(σ)∈[0,1/5] into 400 closed intervals, apply (3) at each left endpoint and the refined input upper bound at each right endpoint. A box is accepted only if the inequalities hold over the entire box. Every unresolved box is bisected in a longest normalized coordinate and both children must be verified. The root domains cover arbitrary coherent or incoherent, pure or mixed inputs.

All arithmetic in the box proof uses integer intervals with fixed denominator 2^40, signed 128-bit intermediates, and outward rounding. Floating-point sqrt supplies only a candidate that is corrected using exact integer square comparisons. A support-size transition overlapping a rounding interval checks every eligible branch. Spin coefficients and the two-copy eigenvalues are separately calculated by exact SymPy arithmetic.
