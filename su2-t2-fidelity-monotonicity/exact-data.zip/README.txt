EXACT DATA APPENDIX TO THE UNIFORM WRITTEN PROOFS (16 November 2026)

This archive is embedded in the PDF. It contains the full previously audited
exact-Python input closure: rational data, checking programs, and dependency
requirements. The PDF defines the mathematical checks and data encodings.
No Lean build is invoked by these programs. Full end-to-end Lean verification
is unfinished and all Lean computations remain stopped.

To independently check these data, extract this archive into an empty folder,
install the dependencies in requirements.txt, and run python3 verify_all.py.
Only that entry point and the verify/check scripts that it invokes are needed.
Some helper modules contain historical generator entry points; do not run
those generators. No numerical optimizer is used by the supported checks.

prior-exact-audit.json records the earlier successful exact-Python audit.
MANIFEST.json identifies every included original input and program by SHA-256.
These bytes were compared with that audit during PDF preparation. The audit
is evidence, not a premise replacing the algebraic checking rules in the PDF.

The printed scalar proof uses the earlier, already audited partition:
55,003 ordinary leaves and 1,184 compact K=3 leaves, total 56,187.
It does not use the smaller partition from the unfinished Lean rebuild.
All file references in the PDF are relative to this extracted archive.
