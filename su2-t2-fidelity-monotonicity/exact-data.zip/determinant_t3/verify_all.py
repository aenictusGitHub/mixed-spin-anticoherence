"""Run the exact certificates required by the order-three determinant proof."""
from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parent
scripts=[
 'bounds/verify_burg_bounds.py',
 'floors/verify_positive_floors.py',
 'structural/verify_clifford_reduction.py',
 'bounds/verify_central_region.py',
 'bounds/certify_k42_outer.py',
 'search/audit_reduction.py',
]
rows=[]
for name in scripts:
 p=subprocess.run([sys.executable,str(ROOT/name)],cwd=ROOT,capture_output=True,text=True)
 rows.append({'script':name,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 print(('PASS ' if p.returncode==0 else 'FAIL ')+name,flush=True)
 if p.returncode:
  print(p.stdout,p.stderr)
  (ROOT/'verification_results.json').write_text(json.dumps(rows,indent=2)+'\n')
  raise SystemExit(p.returncode)
(ROOT/'verification_results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('All exact proof certificates passed.',flush=True)
