"""Independent exact audit of finite multiplier hull and positive-floor maps.
Reads saved certificates; does not regenerate or modify parent proof files.
"""
from pathlib import Path
from itertools import combinations
from math import comb
import json,sympy as s
from sympy.physics.wigner import wigner_6j,clebsch_gordan
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
facets=[tuple(map(s.Integer,r)) for r in json.loads((ROOT/'bounds/finite_hull.json').read_text())['facets']]
physical={(-9,5,-1,5),(-3,-5,3,5),(3,-5,-3,5),(9,5,1,5)}
assert physical<=set(facets)
def f(N,K):
 D=s.Integer(N*(N+2));u=s.Integer(K*(K+1));return s.Matrix([1-2*u/D,1-6*u/D+6*u*(u-2)/(D*(D-3)),1-12*u/D+30*u*(u-2)/(D*(D-3))-20*u*(u-2)*(u-6)/(D*(D-3)*(D-8))])
V={(s.Integer(1),)*3,(-s.Integer(1),s.Integer(1),-s.Integer(1)),(s.Rational(11,15),s.Rational(1,5),-s.Rational(3,5)),(-s.Rational(11,15),s.Rational(1,5),s.Rational(3,5)),(s.Integer(0),-s.Integer(1),s.Integer(0))}
base=[tuple(f(N,K)) for N,K in [(4,2),(4,3),(5,4),(6,5)]];V|=set(base)|{(-a,b,-c) for a,b,c in base}
assert len(V)==13
inside=lambda v,rows: all(sum(r[i]*v[i] for i in range(3))+r[3]>=0 for r in rows)
assert all(inside(v,facets) for v in V)
found=set()
for rows in combinations(facets,3):
 A=s.Matrix([r[:3] for r in rows]);b=s.Matrix([-r[3] for r in rows])
 if A.det()==0:continue
 v=tuple(A.inv()*b)
 if inside(v,facets):found.add(v)
assert found==V
# The four physical facets force every recession direction to zero, so no rays.
posrows=physical|{(0,1,-2,1),(0,1,2,1)}
posfound=set()
for rows in combinations(posrows,3):
 A=s.Matrix([r[:3] for r in rows]);b=s.Matrix([-r[3] for r in rows])
 if A.det()!=0:
  v=tuple(A.inv()*b)
  if inside(v,posrows):posfound.add(v)
assert posfound==V-set(base)-{(-a,b,-c) for a,b,c in base}
for N in range(4,7):
 for K in range(N+1):
  v=f(N,K)
  if N==4:assert inside(v,posrows) or tuple(v) in base[:2]
  elif N==5:
   if K==3:
    decomp=s.Matrix([1,1,1])/63+s.Matrix([-1,1,-1])/42+s.Rational(199,630)*s.Matrix([0,-1,0])+s.Rational(29,45)*s.Matrix(base[0]);assert v==decomp
   else:assert inside(v,posrows) or tuple(v)==base[2]
  else:assert inside(v,facets)
# Independent 6j comparison with explicit multiplier formulas.
ng=0
for N in [4,5,6,7]:
 for K in range(N+1):
  for ell in range(1,4):
   j=s.Rational(N,2);actual=(-1)**(N+K+ell)*(N+1)*wigner_6j(j,j,ell,j,j,K)
   assert actual==f(N,K)[ell-1];ng+=1
Y,Z,y,x=s.symbols('Y Z y x');D=(1-2*y)/y**2
f2=(3*D*x*x-D-6*x)/(2*(D-3));f3=(5*D**2*x**3-3*D**2*x-40*D*x*x+8*D*x+10*D+48*x)/(2*(D-8)*(D-3));Q=2*(1-3*y)*(1+y)*(1-4*y)*(1+2*y)
assert s.cancel(Q-2*(D-3)*(D-8)*y**4)==0
# Every Q factor positive at and throughout y in [0,1/9].
assert 1-4*s.Rational(1,9)>0 and 1-3*s.Rational(1,9)>0
certs=json.loads((ROOT/'bounds/finite_hull_certificates.json').read_text());assert len(certs)==16
assert {tuple(c['facet']) for c in certs}==set(facets)-physical
boxes_total=coeffs_total=0
for cert in certs:
 r=cert['facet'];expr=s.cancel((r[0]*x+r[1]*f2+r[2]*f3+r[3])*Q)
 expr=s.expand(expr.subs(x,-1+2*y+2*(1-y)*Z).subs(y,Y/9));P=s.Poly(expr,Y,Z)
 assert s.expand(expr-s.sympify(cert['polynomial']))==0
 boxes=[]
 for rec in cert['boxes']:
  a,b,c,d,saved=map(s.Rational,rec);assert 0<=a<b<=1 and 0<=c<d<=1;boxes.append((a,b,c,d));boxes_total+=1
  exprbox=s.Poly(P.as_expr().subs({Y:a+(b-a)*Y,Z:c+(d-c)*Z},simultaneous=True).expand(),Y,Z);n,m=exprbox.degree(Y),exprbox.degree(Z)
  bs=[]
  for u in range(n+1):
   for v in range(m+1):
    val=sum(co*s.Rational(comb(u,i),comb(n,i))*s.Rational(comb(v,j),comb(m,j)) for (i,j),co in exprbox.terms() if i<=u and j<=v);assert val>=0;bs.append(val);coeffs_total+=1
  assert min(bs)==saved
 xs=sorted({v for a,b,c,d in boxes for v in [a,b]});zs=sorted({v for a,b,c,d in boxes for v in [c,d]});assert xs[0]==zs[0]==0 and xs[-1]==zs[-1]==1
 for u in range(len(xs)-1):
  for v in range(len(zs)-1):
   cx=(xs[u]+xs[u+1])/2;cz=(zs[v]+zs[v+1])/2
   assert sum(int(bool(a<cx<b and c<cz<d)) for a,b,c,d in boxes)==1
print('HULL_AND_DOMAIN_PASSED',len(V),len(facets),ng,boxes_total,coeffs_total,flush=True)
# Build exact channel superoperators independently from CG amplitudes.
def cg_super(jin,jout,env):
 d=int(2*jin+1);a=int(2*jout+1);Es=s.zeros(a*a,d*d);tp=s.zeros(d)
 for mm in range(int(2*env+1)):
  mu=env-mm;A=s.Matrix(a,d,lambda r,k:clebsch_gordan(jout,env,jin,jout-r,mu,jin-k));tp+=A.T*A;Es+=s.kronecker_product(A,A)
 assert s.simplify(tp-s.eye(d))==s.zeros(d)
 assert s.simplify(Es*s.Matrix(s.eye(d)).reshape(d*d,1)-s.Rational(d,a)*s.Matrix(s.eye(a)).reshape(a*a,1))==s.zeros(a*a,1)
 return Es
# Local half-integer spin reversal and Breuer-Hall maps.
Vrev=s.zeros(4)
for a in range(4):Vrev[a,3-a]=(-1)**a
assert Vrev.T==-Vrev and Vrev*Vrev.T==s.eye(4)
Th=s.Matrix(16,16,lambda ij,kl:Vrev[ij//4,kl%4]*Vrev[ij%4,kl//4]);Id=s.eye(16);TraceI=s.Matrix(16,16,lambda ij,kl:int(ij//4==ij%4)*int(kl//4==kl%4));BH=(TraceI-Id-Th)/2
floors=json.loads((ROOT/'floors/positive_floors.json').read_text());nmap=0
for rec in floors:
 N,K=rec['N'],rec['K'];j=s.Rational(N,2);local=s.Rational(3,2);Gs=[cg_super(j,local,j-local+q) for q in range(4)];R=Gs[0]
 # Verify G0 equals the binomial symmetric partial trace, not just multipliers.
 Rd=s.zeros(16,(N+1)**2)
 for b in range(N-2):
  A=s.zeros(4,N+1)
  for a in range(4):A[a,a+b]=s.sqrt(s.Rational(comb(3,a)*comb(N-3,b),comb(N,a+b)))
  Rd+=s.kronecker_product(A,A)
 assert s.simplify(R-Rd)==s.zeros(16,(N+1)**2)
 Phi=cg_super(j,j,s.Integer(K));target=R*Phi
 dep=s.Matrix(16,(N+1)**2,lambda ij,kl:s.Rational(1,4)*int(ij//4==ij%4)*int(kl//(N+1)==kl%(N+1)))
 w0=s.Rational(rec['depolarizing_weight']);assert w0>0;other=s.Integer(0);rhs=w0*dep
 for typ,q,w in rec['terms']:
  w=s.Rational(w);assert w>0;other+=w;F={'G':Id,'T':Th,'B':BH}[typ];rhs+=w*F*Gs[q]
 assert w0+other==1 and s.Rational(rec['floor'])==w0/4
 assert all(s.simplify(z)==0 for z in target-rhs)
 nmap+=1;print('EXACT_FLOOR_MAP_PASSED',N,K,rec['floor'],flush=True)
report=dict(status='passed',hull_vertices=len(V),hull_facets=len(facets),positive_polytope_vertices=len(posfound),six_j_comparisons=ng,continuous_facets=len(certs),partition_boxes=boxes_total,nonnegative_Bernstein_coefficients=coeffs_total,exact_positive_floor_superoperator_identities=nmap,low_spin_extension_audit='N4 uses only local positive maps and its own bases; N5 exception K3 reduces to N4K2; N6+ have every needed extension.')
(OUT/'audit_reduction.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
