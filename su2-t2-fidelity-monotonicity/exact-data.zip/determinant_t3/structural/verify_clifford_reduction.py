from pathlib import Path
import sympy as s,json
j=s.Rational(3,2);Jp=s.zeros(4)
for k in range(1,4):Jp[k-1,k]=s.sqrt(k*(4-k))
Jm=Jp.T;Jx=(Jp+Jm)/2;Jy=(Jp-Jm)/(2*s.I);Jz=s.diag(j,j-1,j-2,j-3);I=s.eye(4)
G=[(Jy*Jz+Jz*Jy)/s.sqrt(3),(Jz*Jx+Jx*Jz)/s.sqrt(3),(Jx*Jy+Jy*Jx)/s.sqrt(3),(Jx*Jx-Jy*Jy)/s.sqrt(3),Jz*Jz-s.Rational(5,4)*I]
for a in range(5):
 for b in range(5): assert s.simplify(G[a]*G[b]+G[b]*G[a]-2*int(a==b)*I)==s.zeros(4)
T20=s.diag(1,-1,-1,1)/2;T30=s.diag(1,-3,3,-1)/(2*s.sqrt(5))
assert s.trace(T20*T20)==1 and s.trace(T30*T30)==1
assert Jz-T20==s.diag(1,1,0,-2)
assert Jz-s.sqrt(5)*T30/2==s.diag(s.Rational(5,4),s.Rational(5,4),-s.Rational(5,4),-s.Rational(5,4))
r,z,w,S,E=s.symbols('r z w S E',real=True)
Vout=r*r/20+s.Rational(9,196)*z*z+s.Rational(16,49)*w
bound=s.factor(Vout.subs(w,s.Rational(1,4)-4*r*r/45).subs(z,(S-r)/3))
assert s.simplify(bound-(s.Rational(4,49)+37*r*r/1764+(S-r)**2/196))==0
U=s.factor(bound.subs(r,s.Rational(3,2)));assert s.simplify(U.subs(S,3-E)-(55-6*E+2*E*E)/392)==0
assert s.simplify(U-bound.subs(r,S-s.Rational(3,2))-(s.Rational(1,28)-(S-s.Rational(3,2))**2/63))==0
out={'Clifford_relations':True,'T20_T30_operator_bounds':True,'output_variance_formulas':True,'all_exact_checks_passed':True}
Path(__file__).with_name('clifford_reduction_verification.json').write_text(json.dumps(out,indent=2));print(out)
