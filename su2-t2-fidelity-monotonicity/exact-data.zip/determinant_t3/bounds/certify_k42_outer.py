"""Exact rational certificate for the K42 outer scalar regime.

Epsilon = 3 - (r + 3 sqrt(u)).  The interval [1/8,2/5] is
partitioned into 275 intervals of length 1/1000.  All logarithms are
bounded by rational atanh-series partial sums after power-of-two
range reduction; all square roots use exact integer square roots.
"""
from fractions import Fraction as F
from math import isqrt, factorial
from pathlib import Path
import json

TERMS=12
SCALE=2**40

def log_bounds(x):
    assert x>0
    if x<1:
        lo,hi=log_bounds(1/x);return -hi,-lo
    k=0
    while x>=2:x/=2;k+=1
    r=(x-1)/(x+1)
    def series(q):
        lo=2*sum((q**(2*j+1)/F(2*j+1) for j in range(TERMS)),F(0))
        hi=lo+2*q**(2*TERMS+1)/(F(2*TERMS+1)*(1-q*q))
        return lo,hi
    l2,u2=series(F(1,3));lo,hi=series(r)
    return k*l2+lo,k*u2+hi

def input_L_lower(epsilon):
    if epsilon<=F(1,4):v=F(3,4)-epsilon+epsilon*epsilon
    else:v=F(1,4)+(F(3,2)-epsilon)**2/5
    rootarg=F(3,4)*v
    root=F(isqrt(rootarg.numerator*SCALE*SCALE//rootarg.denominator),SCALE)
    assert root*root<=rootarg<(root+F(1,SCALE))**2
    a=F(1,4)+root
    ratio=27/(256*a*(1-a)**3)
    return log_bounds(ratio)[0],a

def output_L_upper(epsilon):
    m=epsilon/28
    log_upper=log_bounds(27/(256*m*(1-m)**3))[1]
    C=12*log_upper/(1-4*m)**2
    vout=(55-6*epsilon+2*epsilon**2)/392
    return C*vout

# Analytic near-zero regime constants.
A=F(1056,605)
assert F(12)*F(55,392)/(1-F(1,56))**2==A
constant=F(189,64)*F(224,223)**3
x=F(11,10)
assert sum((x**k/F(factorial(k)) for k in range(7)),F(0))>constant
assert 1+F(1,5)>F(32,27)
assert 2*(3-A)-F(11,10)*A-F(1,5)==F(1177,3025)>0
print('Analytic 0 < epsilon <= 1/8 constants verified exactly.')

rows=[];minimum=None
for k in range(125,400):
    left=F(k,1000);right=F(k+1,1000)
    lower,ainput=input_L_lower(right)
    upper=output_L_upper(left)
    gap=lower-upper
    assert gap>0,(left,right,float(gap))
    if minimum is None or gap<minimum[0]:minimum=(gap,left,right)
    rows.append({'left':str(left),'right':str(right),'input_large_eigenvalue_lower':str(ainput),'gap_lower':str(gap)})
print('All',len(rows),'outer intervals certified exactly.')
print('Smallest certified gap',float(minimum[0]),'on',minimum[1],minimum[2])
(Path(__file__).parent/'k42_outer_certificates.json').write_text(json.dumps({'log_terms':TERMS,'sqrt_scale':SCALE,'intervals':rows},indent=2))
