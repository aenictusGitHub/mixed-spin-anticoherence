"""Rational certificates for K=2, spin2, s=r+3sqrt(u)<=13/5."""
import sympy as S
from pathlib import Path
import json
Q=S.Rational

def log_upper(x, terms=40):
 r=S.cancel((x-1)/(x+1))
 assert 0<=r<1
 return sum(2*r**(2*k+1)/Q(2*k+1) for k in range(terms))+2*r**(2*terms+1)/(Q(2*terms+1)*(1-r*r))

def C_upper(m):
 x=27/(256*m*(1-m)**3)
 return 12*log_upper(x)/(1-4*m)**2

rows=[(Q(0),Q(8,5),Q(16,49),Q(18)),
      (Q(8,5),Q(2),Q(4,15),Q(20)),
      (Q(2),Q(12,5),Q(1,4),Q(24)),
      (Q(12,5),Q(5,2),Q(23,100),Q(26)),
      (Q(5,2),Q(13,5),Q(11,50),Q(277,10))]
cert=[]
for lo,hi,b,Cbound in rows:
 m=(3-hi)/28
 cup=C_upper(m)
 assert cup<Cbound
 assert b*Cbound<Q(49,8)
 rec={'s_interval':[str(lo),str(hi)],'Vout_over_V':str(b),'floor':str(m),'C_bound':str(Cbound),'product':str(b*Cbound),'strict_gap':str(Q(49,8)-b*Cbound)}
 if lo:
  A=196*b-37;B=196*b-9
  assert A>0 and B>0
  l=max(0,lo-Q(3,2));h=min(Q(3,2),lo)
  critical=B*lo/(A+B)
  at=min(max(critical,l),h)
  minimum=S.cancel(441*b-144+A*at**2+B*(lo-at)**2)
  assert minimum>0
  rec.update({'quadratic_minimizer':str(at),'quadratic_minimum':str(minimum)})
 cert.append(rec)
 print(f's in [{lo},{hi}]: C < {Cbound}, Vout/V <= {b}, product {b*Cbound} < 49/8.')
Path(__file__).with_name('central_region_certificates.json').write_text(json.dumps(cert,indent=2)+'\n')
print('All central-region inequalities verified exactly.')
