"""Exact rational and symbolic checks for the Burg-deficit bounds."""
import sympy as s

a=s.symbols('a',positive=True)
L=-s.log(s.Rational(256,27)*a*(1-a)**3)
V=s.Rational(4,3)*(a-s.Rational(1,4))**2
c=s.Rational(49,8)
assert s.factor(s.diff(L-c*V,a)-(4*a-1)*(1/(a*(1-a))-s.Rational(49,12)))==0
assert s.solve(1-s.Rational(49,12)*a*(1-a),a)==[s.Rational(3,7),s.Rational(4,7)]
assert s.simplify((c*V).subs(a,s.Rational(4,7)))==s.Rational(27,32)
r=s.Rational(1377,3425)
assert 2*(r+r**3/3)-s.Rational(27,32)==s.Rational(4707658629,1285676500000)>0
print('Global L >= (49/8)V: exact derivative and logarithm certificate passed.')

m=s.Rational(11,280)
R=s.factor(27/(256*m*(1-m)**3))
assert R==s.Rational(648270000,214116199)
assert s.factor(s.Rational(16,49)*12/(1-4*m)**2)==s.Rational(19200,3481)
assert s.Rational(109,36)-R==s.Rational(945691,7708183164)>0
r=s.Rational(73,145)
U=2*(r+r**3/3)+2*r**5/(5*(1-r*r))
assert s.Rational(111,100)-U==s.Rational(84307637,119628045000)>0
assert c-s.Rational(19200,3481)*s.Rational(111,100)==s.Rational(73,27848)>0
print('N=4,K=3: exact upper-log certificate closes the determinant criterion.')

x=s.Rational(24,25)
assert sum(x**k/s.factorial(k) for k in range(4))>s.Rational(16875,6859)
assert s.Rational(23,378)>s.Rational(1,20)
assert s.Rational(7,120)>s.Rational(1,20)
assert s.Rational(18,4)<c
print('N=5,K=4 and N=6,K=5: exact floor and upper-log checks passed.')
