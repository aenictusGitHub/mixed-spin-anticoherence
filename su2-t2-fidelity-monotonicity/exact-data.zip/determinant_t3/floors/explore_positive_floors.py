from pathlib import Path
import sys
import sympy as s
from sympy.physics.wigner import clebsch_gordan
R=s.Rational

def vertices(N):
 j=R(N,2);a=R(3,2);B=j-a
 # tensor diagonal on input and output, normalization irrelevant across channels
 Tin=[s.diag(*[clebsch_gordan(j,l,j,j-b,0,j-b) for b in range(N+1)]) for l in range(1,4)]
 vals=[]
 for q in range(4):
  b=B+q
  ops=[]
  for c in range(int(2*b)+1):
   e=b-c
   ops.append(s.Matrix(4,N+1,lambda r,k:clebsch_gordan(a,b,j,a-r,e,j-k)))
  ims=[sum((A*T*A.T for A in ops),s.zeros(4)) for T in Tin]
  diag=[im[0,0] for im in ims]
  vals.append(diag)
 return [[s.simplify(vals[q][l]/vals[0][l]) for l in range(3)] for q in range(4)]

def f(N,K):
 D=N*(N+2);u=K*(K+1)
 return [1-R(2*u,D),1-R(6*u,D)+R(6*u*(u-2),D*(D-3)),1-R(12*u,D)+R(30*u*(u-2),D*(D-3))-R(20*u*(u-2)*(u-6),D*(D-3)*(D-8))]

if __name__=='__main__':
 import numpy as np
 from scipy.optimize import linprog
 for N,K in [(4,2),(4,3),(5,4),(6,5)]:
  v=vertices(N)
  pp=[];labels=[]
  for q,row in enumerate(v):
   pp.extend([row,[-row[0],row[1],-row[2]],[0,-row[1],0]])
   labels.extend([f'G{q}',f'TG{q}',f'BG{q}'])
  tar=f(N,K)
  # maximize radial expansionz: sumw*pp=z*tar, sumw1
  A=np.block([[np.array(pp,float).T,-np.array(tar,float).reshape(3,1)],[np.ones((1,len(pp))),np.zeros((1,1))]])
  c=np.zeros(len(pp)+1);c[-1]=-1
  res=linprog(c,A_eq=A,b_eq=[0,0,0,1],bounds=[(0,None)]*(len(pp)+1),method='highs')
  ids=np.flatnonzero(res.x[:-1]>1e-7)
  Ae=s.Matrix([[pp[i][l] for i in ids]+[-tar[l]] for l in range(3)]+[[1]*len(ids)+[0]])
  exact=list(s.linsolve((Ae,s.Matrix([0,0,0,1]))))[0]
  z=exact[-1];m=s.simplify((1-1/z)/4)
  print(N,K,'G=',v,'floor',m,float(m), 'decomp', [(labels[i],str(exact[k])) for k,i in enumerate(ids)],flush=True)
