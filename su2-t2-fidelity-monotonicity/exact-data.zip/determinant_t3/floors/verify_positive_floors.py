"""Exact CG and positive-map certificates for three determinant base cases."""
from explore_positive_floors import vertices, f, R
import sympy as s
from pathlib import Path
import json

certificates = [
 (4,3,R(11,70), [('B',0,R(1,7)),('T',1,R(1,10)),('G',2,R(3,5))]),
 (5,4,R(46,189), [('B',0,R(170,567)),('T',1,R(140,567)),('G',2,R(119,567))]),
 (6,5,R(7,30), [('T',0,R(1,25)),('B',0,R(11,30)),('T',1,R(9,25))]),
]
records=[]
for N,K,w0,terms in certificates:
 v=vertices(N)
 assert w0>0 and all(w>0 for _,_,w in terms)
 assert w0+sum(w for _,_,w in terms)==1
 vv=s.zeros(3,1)
 for typ,q,w in terms:
  x,y,z=v[q]
  p={'G':[x,y,z],'T':[-x,y,-z],'B':[0,-y,0]}[typ]
  vv+=w*s.Matrix(p)
 assert list(vv)==f(N,K)
 floor=w0/4
 records.append(dict(N=N,K=K,floor=str(floor),depolarizing_weight=str(w0),terms=[(a,q,str(w)) for a,q,w in terms],G=[[str(x) for x in row] for row in v]))
 print(f'N={N}, K={K}: exact positive decomposition verified; output floor {floor}.')
Path(__file__).with_name('positive_floors.json').write_text(json.dumps(records,indent=2)+'\n')
