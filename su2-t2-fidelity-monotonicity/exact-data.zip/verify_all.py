"""Run every exact computer certificate for the t=3 and t=4 determinant proofs.

This is an exact Python verification suite, not a Lean proof. The standalone
order-four suite covers thirteen base cases; its final exceptional case is
checked separately by the weighted-SOS verifier below.
"""
from pathlib import Path
import importlib.metadata
import json
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
CHECKS = [
    'determinant_t3/verify_all.py',
    'determinant_t4/verify_all.py',
    'determinant_t4/exact_cube_sos/verify_exact_sos.py',
    'determinant_t4/exact_cube_sos/verify_exact_kernels.py',
]

def main():
    if sys.flags.optimize:
        raise SystemExit('Run Python without -O/PYTHONOPTIMIZE: certificate assertions must be enabled.')
    report = {
        'python': sys.version,
        'platform': platform.platform(),
        'dependencies': {name: importlib.metadata.version(name)
                         for name in ['sympy', 'numpy', 'python-flint']},
        'checks': [],
        'verification_type': 'exact Python certificate verification; not Lean',
    }
    for name in CHECKS:
        path = ROOT / name
        start = time.monotonic()
        run = subprocess.run([sys.executable, str(path)], cwd=path.parent,
                             text=True, capture_output=True)
        report['checks'].append({'script': name, 'returncode': run.returncode,
                                 'seconds': time.monotonic()-start,
                                 'stdout': run.stdout, 'stderr': run.stderr})
        report['status'] = 'PASS' if all(r['returncode'] == 0 for r in report['checks']) else 'FAIL'
        (ROOT / 'verification-report.json').write_text(json.dumps(report, indent=2)+'\n')
        print(('PASS ' if run.returncode == 0 else 'FAIL ')+name, flush=True)
        if run.returncode:
            print(run.stdout, run.stderr, flush=True)
            raise SystemExit(run.returncode)
    print('PASS: all order-three and all fourteen order-four determinant base cases.', flush=True)

if __name__ == '__main__':
    main()
