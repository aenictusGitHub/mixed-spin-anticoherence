"""Exact multipliers; only SymPy and the Python standard library are required."""
from sympy import Rational,rf,factorial,simplify
from sympy.physics.wigner import wigner_6j

def fexact(N,K,l):
 return sum(rf(-l,r)*rf(l+1,r)*rf(-K,r)*rf(K+1,r)/(rf(1,r)*rf(-N,r)*rf(N+2,r)*factorial(r)) for r in range(min(l,K)+1))

def globalG(N,t,exact=True):
 j=Rational(N,2);a=Rational(t,2);b0=j-a
 G=[[simplify((-1)**q*wigner_6j(a,a,l,j,j,b0+q)/wigner_6j(a,a,l,j,j,b0)) for q in range(t+1)] for l in range(1,t+1)]
 return G if exact else [[float(x) for x in row] for row in G]
