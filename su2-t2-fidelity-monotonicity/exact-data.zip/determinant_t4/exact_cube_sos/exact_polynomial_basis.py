"""Exact rational covariants reconstructed from suggested highest rows.

Every reconstructed raw covariant is verified by exact Lie-algebra identities.
Kernel restrictions are imposed by exact coefficient equations, not tolerances.
"""
from pathlib import Path
from fractions import Fraction
from itertools import product
from math import comb
import sys,json,numpy as np
from flint import fmpq,fmpq_mat
P=Path(__file__).resolve().parent
def add(d,k,v):
 if not v:return
 d[k]=d.get(k,fmpq(0))+v
 if not d[k]:del d[k]
def digits(c,source):return [c] if source==1 else [c//36,(c//6)%6,c%6]
def index(ds):return ds[0] if len(ds)==1 else ds[0]*36+ds[1]*6+ds[2]
def action(row,sign,source):
 out={}
 for (mon,c),v in row.items():
  for pos,h in enumerate(mon):
   a,b=divmod(h,6)
   moves=[(a+1,b,5-a),(a,b-1,-b)] if sign==1 else [(a-1,b,a),(a,b+1,-(5-b))]
   for aa,bb,m in moves:
    if m:
     new=list(mon);new[pos]=aa*6+bb;add(out,(tuple(sorted(new)),c),m*v)
  ds=digits(c,source)
  for pos,h in enumerate(ds):
   m=(5-h) if sign==1 else h
   if m:
    new=ds.copy();new[pos]+=sign;add(out,(mon,index(new)),m*v)
 return out
def nullspace(rows,n):
 if not rows:return fmpq_mat(n,n,[int(i==j) for i in range(n) for j in range(n)])
 M=fmpq_mat([[row.get(k,fmpq(0)) for k in range(n)] for row in rows]);RR,rank=M.rref();piv=[]
 for i in range(rank):piv.append(next(j for j in range(n) if RR[i,j]))
 free=[j for j in range(n) if j not in piv];N=fmpq_mat(n,len(free))
 for k,j in enumerate(free):
  N[j,k]=1
  for i,p in enumerate(piv):N[p,k]=-RR[i,j]
 return N
def constrain(raw,source,bad):
 eq={}
 for a,Q in enumerate(raw):
  for r,row in enumerate(Q):
   pure={}
   for (mon,c),v in row.items():
    src=digits(c,source)
    if all(h in [0,1,6,7] for h in mon) and all(t<2 for t in src):add(eq.setdefault(('support',r,c,mon),{}),a,v)
    if all(h==0 for h in mon) and (source==1 or sum(t!=0 for t in src)<=1):add(eq.setdefault(('coherent',r,c),{}),a,v)
    hol=[0]*6;anti=[0]*6
    for h in mon:aa,bb=divmod(h,6);hol[aa]+=1;anti[bb]+=1
    for t in src:hol[t]+=1
    if tuple(x+y for x,y in zip(hol,anti)) in bad:add(pure,(tuple(hol),tuple(anti)),v)
   for key,v in pure.items():add(eq.setdefault(('newton',r,key),{}),a,v)
 return nullspace([v for v in eq.values() if v],len(raw))
def combine(raw,N):
 out=[]
 for k in range(N.ncols()):
  rows=[{} for _ in raw[0]]
  for a,Q in enumerate(raw):
   if N[a,k]:
    for r,row in enumerate(Q):
     for key,v in row.items():add(rows[r],key,N[a,k]*v)
  out.append(rows)
 return out
def dumpQ(Q):return [[[[list(map(int,mon)),int(c),str(v)] for (mon,c),v in sorted(row.items())] for row in q] for q in Q]
def loadQ(data):return [[{(tuple(mon),c):fmpq(v) for mon,c,v in row} for row in q] for q in data]
if __name__=='__main__':
 from scipy.linalg import qr
 c1=np.load(P/'rational_top_explore.npz');cube=np.load(P/'cube_top_explore.npz');pairs=list(zip(*np.triu_indices(36)));bad=set(map(tuple,json.loads((P/'pure_newton.json').read_text())['bad']))
 selected=list(map(int,sys.argv[1:])) if len(sys.argv)>1 else list(range(9))+list(range(18,26));reports=[]
 for k in selected:
  d=c1 if k<9 else cube;J2=2*k+1 if k<9 else int(d[f'{k}_J2']);source=1 if k<9 else 3;nsource=6**source;monomials=pairs if source==1 else [(i,) for i in range(36)];R=d[f'{k}_raw'];T=np.eye(R.shape[1])
  if k>=26:
   groups={}
   for a,(s2,mult,ell) in enumerate(d[f'{k}_labels']):groups.setdefault((s2,ell),[]).append(a)
   for ids in groups.values():
    H=R[:,ids];_,_,p=qr(H.T,pivoting=True,mode='economic');T[np.ix_(ids,ids)]=np.linalg.inv(H[p[:len(ids)]])
   R=R@T
  f=np.max(abs(R),axis=0);raw=[];err=0.;maxden=0
  for a in range(R.shape[1]):
   top={}
   for flat in np.flatnonzero(abs(R[:,a]/f[a])>1e-11):
    p,c=divmod(int(flat),nsource);v=Fraction(float(R[flat,a]/f[a])).limit_denominator(10000000);err=max(err,abs(float(v)-R[flat,a]/f[a]));maxden=max(maxden,v.denominator);top[(tuple(monomials[p]),c)]=fmpq(v.numerator,v.denominator)
   assert not action(top,-1,source),('highest-weight identity failed',k,a,len(action(top,-1,source)))
   for (mon,c),v in top.items():assert sum(2*((h%6)-(h//6)) for h in mon)+5*source-2*sum(digits(c,source))==J2
   Q=[top]
   for r in range(J2):Q.append({key:v/(J2-r) for key,v in action(Q[-1],1,source).items()})
   assert not action(Q[-1],1,source),('lowest-weight identity failed',k,a)
   raw.append(Q)
  if k<9 or k>=18:N=constrain(raw,source,bad)
  else:N=fmpq_mat(len(raw),len(raw),[int(i==j) for i in range(len(raw)) for j in range(len(raw))])
  Q=combine(raw,N);Nf=np.array([[float(N[i,j]) for j in range(N.ncols())] for i in range(N.nrows())]);new=T@(Nf/f[:,None]);C=np.linalg.lstsq(d[f'{k}_N'],new,rcond=1e-11)[0];res=float(np.linalg.norm(d[f'{k}_N']@C-new)/np.linalg.norm(new));assert res<1e-8,(k,'different constrained space',res)
  data=dict(block=k,J2=J2,source=source,dimension=len(Q),N=[[str(N[i,j]) for j in range(N.ncols())] for i in range(N.nrows())],Q=dumpQ(Q));(P/f'exact_basis_{k}.json').write_text(json.dumps(data,separators=(',',':')));np.save(P/f'exact_transform_{k}.npy',C)
  rep=dict(block=k,J2=J2,raw=len(raw),constrained=len(Q),old_dimension=d[f'{k}_N'].shape[1],reconstruction_error=err,max_denominator=maxden,change_of_basis_residual=res,exact_covariance=True,exact_zero_constraints=True);reports.append(rep);print(rep,flush=True)
 (P/'exact_basis_report.json').write_text(json.dumps(reports,indent=2))
