"""Integer evaluation of the rational reduced SOS basis on the certified grid."""
from pathlib import Path
from itertools import permutations
from math import comb
import sys,json,pickle,time,numpy as np
from flint import fmpq,fmpz_mat
P=Path(__file__).resolve().parent
PERMS=[(p,(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))) for p in permutations(range(5))]
def det_gaussian(R,I):
 totalr=totali=0
 for perm,sgn in PERMS:
  a,b=sgn,0
  for i,j in enumerate(perm):c,d=int(R[i,j]),int(I[i,j]);a,b=a*c-b*d,a*d+b*c
  totalr+=a;totali+=b
 assert totali==0
 return totalr
class Evaluator:
 def __init__(self):
  src=json.loads((P/'source_bases.json').read_text());self.sources={k:np.array(v['matrix'],dtype=np.int64) for k,v in src.items()};self.blocks=[];self.denoms=[];self.dimensions=[];self.pairs=list(zip(*np.triu_indices(36)));pairpos={p:i for i,p in enumerate(self.pairs)}
  assert all(np.max(np.abs(S))<=2 and np.max(np.sum(np.abs(S),axis=1))<=6 for S in self.sources.values())
  for k in range(35):
   d=json.loads((P/f'exact_reduced_basis_{k}.json').read_text());ds=list(map(int,d['denominators']));n=d['dimension'];self.dimensions.append(n);self.denoms.extend(ds[i]*ds[j] for i in range(n) for j in range(i,n));terms=[];s=d['source_dimension']
   for q in d['Q_integer']:
    terms.append([(r*s+c,(mon[0] if len(mon)==1 else pairpos[tuple(mon)]),int(v)) for r,row in enumerate(q) for mon,c,v in row])
   self.blocks.append((d,terms))
  self.channel=[(r,c,a,b,int(fmpq(v)*140)) for r,c,a,b,v in json.loads((P.parent/'coherent_sos/channel_rational.json').read_text())]
 def evaluate(self,hr,hi):
  # These bounds make every fixed-width integer operation below exact:
  # cubic tensor entries have magnitude <=32 and compressed weights <=1152.
  assert np.max(np.abs(hr))<=2 and np.max(np.abs(hi))<=2
  h=hr.reshape(36);g=hi.reshape(36);mR=np.array([int(h[a])*int(h[b])-int(g[a])*int(g[b]) for a,b in self.pairs]);mI=np.array([int(h[a])*int(g[b])+int(g[a])*int(h[b]) for a,b in self.pairs]);kr=np.kron
  CR=kr(kr(hr,hr),hr)-kr(kr(hr,hi),hi)-kr(kr(hi,hr),hi)-kr(kr(hi,hi),hr)
  CI=kr(kr(hr,hr),hi)+kr(kr(hr,hi),hr)+kr(kr(hi,hr),hr)-kr(kr(hi,hi),hi)
  weights={'rho':(fmpz_mat(hr.tolist()),fmpz_mat(hi.tolist()))}
  for kind,S in self.sources.items():
   if kind!='rho':weights[kind]=(fmpz_mat((S@CR@S.T).tolist()),fmpz_mat((S@CI@S.T).tolist()))
  features=[]
  for d,terms in self.blocks:
   n=d['dimension'];s=d['source_dimension'];rows=d['J2']+1;width=rows*s;vr,vi=(mR,mI) if d['kind']=='rho' else (h,g);vr=list(map(int,vr));vi=list(map(int,vi));qr=[];qi=[]
   for q in terms:
    ar=[0]*width;ai=[0]*width
    for pos,mon,v in q:
     if vr[mon]:ar[pos]+=v*vr[mon]
     if vi[mon]:ai[pos]+=v*vi[mon]
    qr.append(ar);qi.append(ai)
   WR,WI=weights[d['kind']];br=[[] for _ in range(n)];bi=[[] for _ in range(n)]
   for r in range(rows):
    a=r*s;b=a+s;QR=fmpz_mat([v[a:b] for v in qr]);QI=fmpz_mat([v[a:b] for v in qi]);BR=(QR*WR-QI*WI)*comb(d['J2'],r);BI=(QR*WI+QI*WR)*comb(d['J2'],r)
    for i in range(n):br[i].extend(BR[i,j] for j in range(s));bi[i].extend(BI[i,j] for j in range(s))
   GG=fmpz_mat(br)*fmpz_mat(qr).transpose()+fmpz_mat(bi)*fmpz_mat(qi).transpose()
   features.extend(int(GG[i,j])*(1 if i==j else 2) for i in range(n) for j in range(i,n))
  AR=hr[:5,:5]+hr[1:,1:];AI=hi[:5,:5]+hi[1:,1:];BR=np.zeros((5,5),np.int64);BI=BR.copy()
  for r,c,a,b,v in self.channel:BR[r,c]+=v*hr[a,b];BI[r,c]+=v*hi[a,b]
  target=96*(fmpq(det_gaussian(BR,BI),140**5)-det_gaussian(AR,AI))
  return features,str(target)
if __name__=='__main__':
 start=int(sys.argv[1]) if len(sys.argv)>1 else 0;stop=int(sys.argv[2]) if len(sys.argv)>2 else 432;ev=Evaluator();grid=np.load(P/'invariant_grid.npz');directory=P/'exact_evaluations';directory.mkdir(exist_ok=True);t=time.time();print('Loaded exact evaluator',len(ev.denoms),'variables',flush=True)
 (directory/'metadata.json').write_text(json.dumps(dict(dimensions=ev.dimensions,denominators=list(map(str,ev.denoms))),separators=(',',':')))
 for k in range(start,stop):
  path=directory/f'{k:03d}.pkl'
  if path.exists():continue
  val=ev.evaluate(grid['real'][k],grid['imag'][k]);path.write_bytes(pickle.dumps(val,protocol=5))
  if (k-start)%5==0:print('Exact evaluation',k,'seconds',time.time()-t,flush=True)
