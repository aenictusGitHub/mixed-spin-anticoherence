"""Check the 20 rational kernel constraints and both coefficient relations."""
from pathlib import Path
from math import comb
from itertools import permutations
import json,time
from flint import fmpq,fmpq_mat
from exact_polynomial_basis import loadQ,action
from exact_pure_features import ctx,gens,pure,conjugate,load_poly
P=Path(__file__).resolve().parent
def matrix(data):return fmpq_mat([[fmpq(v) for v in row] for row in data])
def psd_rank(M):
 S=fmpq_mat(M);rank=0
 while S.nrows():
  n=S.nrows();diag=[S[i,i] for i in range(n)];assert all(v>=0 for v in diag)
  if not any(diag):assert not any(S.entries());break
  k=max(range(n),key=lambda i:diag[i]);p=S[k,k];ids=[i for i in range(n) if i!=k];S=fmpq_mat([[S[i,j]-S[i,k]*S[k,j]/p for j in ids] for i in ids]) if ids else fmpq_mat(0,0);rank+=1
 return rank
if __name__=='__main__':
 t=time.time();data=json.loads((P/'exact_pure_features.json').read_text());proof=json.loads((P/'exact_kernel_constraints.json').read_text());basis=[load_poly(p) for p in data['basis']];F=[[fmpq(v) for v in row] for row in data['F']];target_coeff=[fmpq(v) for v in data['b']];labels=data['labels'];col=0;blocks=list(range(9))+list(range(18,26))
 for k in blocks:
  d=json.loads((P/f'exact_basis_{k}.json').read_text());Q=loadQ(d['Q']);J=d['J2']
  for q in Q:
   assert not action(q[0],-1,d['source'])
   for r in range(J):assert action(q[r],1,d['source'])=={key:(J-r)*v for key,v in q[r+1].items()}
   assert not action(q[-1],1,d['source'])
  Q=pure(Q,d['source']);CQ=[[conjugate(p) for p in q] for q in Q]
  for a in range(len(Q)):
   for b in range(a,len(Q)):
    assert labels[col]==[k,a,b];p=sum((comb(J,r)*CQ[a][r]*Q[b][r] for r in range(J+1)),ctx.constant(0));p=p+conjugate(p) if a!=b else p
    assert p==sum((F[i][col]*v for i,v in enumerate(basis)),ctx.constant(0)),('pure polynomial identity',k,a,b);col+=1
  print('Exact pure Gram polynomials verified for block',k,flush=True)
 BB=[[ctx.constant(0) for _ in range(5)] for _ in range(5)]
 for r,c,a,b,v in json.loads((P.parent/'coherent_sos/channel_rational.json').read_text()):BB[r][c]+=fmpq(v)*gens[a]*gens[6+b]
 target=ctx.constant(0)
 for perm in permutations(range(5)):
  p=ctx.constant(96*(-1)**sum(perm[i]>perm[j] for i in range(5) for j in range(i+1,5)))
  for i,j in enumerate(perm):p*=BB[i][j]
  target+=p
 assert target==sum((v*p for v,p in zip(target_coeff,basis)),ctx.constant(0))
 fun=[[fmpq(v) for v in u] for u in proof['functionals']];assert fmpq_mat(fun).rank()==2
 ma=(3,0,1,0,1,0,3,0,1,0,1,0);mb=(3,0,1,0,1,0,3,0,0,2,0,0);mc=(3,0,0,2,0,0,3,0,0,2,0,0);factor=fmpq(534600,1883077)
 for i,p in enumerate(basis):
  assert fun[0][i]==factor*(p[ma]+4*p[mb]+4*p[mc])
  assert fun[1][i]==factor*(p[ma]+2*p[mb])
 kap=fmpq(1259712,52521875);assert (target[ma],target[mb],target[mc])==(4*kap,-2*kap,kap)
 assert all(sum((a*b for a,b in zip(u,target_coeff)),fmpq(0))==0 for u in fun)
 count=0
 for k in blocks:
  K=proof['kernels'][str(k)];n=K['old_dimension'];N=matrix(K['kernel']);C=matrix(K['constraints']) if K['rank'] else fmpq_mat(0,n);assert C.nrows()==C.rank()==K['rank'];assert N.rank()==K['new_dimension'];assert not any((C*N).entries());Ms=[fmpq_mat(n,n),fmpq_mat(n,n)]
  for j,(kk,a,b) in enumerate(labels):
   if kk!=k:continue
   for M,u in zip(Ms,fun):M[a,b]=M[b,a]=sum((u[i]*F[i][j] for i in range(len(basis))),fmpq(0))/(1 if a==b else 2)
  assert psd_rank(Ms[0])==K['rank'];assert not any((Ms[0]*N).entries());assert not any((N.transpose()*Ms[1]*N).entries());count+=K['rank']
 assert count==20
 report=dict(status='PASS_EXACT_20_KERNELS_AND_TWO_RELATIONS',kernel_constraints=count,independent_relations=2,target_pairings=['0','0'],coefficient_block_scale=str(kap),relations=['a + 4 b + 4 c = 0','a + 2 b = 0'],positive_exposing_functional=True,second_relation_zero_on_reduced_space=True,elapsed_seconds=time.time()-t)
 (P/'exact_kernel_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
