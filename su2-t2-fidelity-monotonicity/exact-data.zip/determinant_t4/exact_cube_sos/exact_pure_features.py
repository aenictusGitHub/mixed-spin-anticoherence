"""Exact polynomial-coordinate map for the pure-input restrictions of SOS terms."""
from pathlib import Path
from itertools import permutations
from math import comb
import json,time
from flint import fmpq,fmpq_mpoly_ctx
from exact_polynomial_basis import loadQ,digits,add
P=Path(__file__).resolve().parent;ctx=fmpq_mpoly_ctx.get(tuple('z'+str(k) for k in range(6))+tuple('w'+str(k) for k in range(6)));gens=ctx.gens()
def conjugate(p):return ctx.from_dict({key[6:]+key[:6]:v for key,v in p.to_dict().items()})
def pure(Q,source):
 out=[]
 for q in Q:
  rows=[]
  for row in q:
   poly={}
   for (mon,c),v in row.items():
    ex=[0]*12
    for h in mon:a,b=divmod(h,6);ex[a]+=1;ex[6+b]+=1
    for k in digits(c,source):ex[k]+=1
    add(poly,tuple(ex),v)
   rows.append(ctx.from_dict(poly))
  out.append(rows)
 return out
def dump_poly(p):return [[list(map(int,key)),str(v)] for key,v in p.to_dict().items()]
def load_poly(data):return ctx.from_dict({tuple(key):fmpq(v) for key,v in data})
if __name__=='__main__':
 basis=[];pivots=[];features=[];labels=[];t=time.time();blocks=list(range(9))+list(range(18,26))
 def reduce(p,extend=True):
  coeff={}
  for k,(b,key) in enumerate(zip(basis,pivots)):
   val=p[key]
   if val:coeff[k]=val;p-=val*b
  if p:
   assert extend,'target outside exact pure feature span'
   key=p.monomial(0);v=p[key];coeff[len(basis)]=v;basis.append(p/v);pivots.append(key)
  return coeff
 for k in blocks:
  d=json.loads((P/f'exact_basis_{k}.json').read_text());Q=pure(loadQ(d['Q']),d['source']);CQ=[[conjugate(q) for q in row] for row in Q];J2=d['J2']
  for a in range(len(Q)):
   for b in range(a,len(Q)):
    p=sum((comb(J2,r)*CQ[a][r]*Q[b][r] for r in range(J2+1)),ctx.constant(0))
    p=(p+conjugate(p)) if a!=b else p
    features.append(reduce(p));labels.append([k,a,b])
  print('block',k,'features',len(features),'exact rank',len(basis),'seconds',time.time()-t,flush=True)
 BB=[[ctx.constant(0) for _ in range(5)] for _ in range(5)]
 for r,c,a,b,v in json.loads((P.parent/'coherent_sos/channel_rational.json').read_text()):BB[r][c]+=fmpq(v)*gens[a]*gens[6+b]
 target=ctx.constant(0)
 for perm in permutations(range(5)):
  p=ctx.constant(96*(-1)**sum(perm[i]>perm[j] for i in range(5) for j in range(i+1,5)))
  for i,j in enumerate(perm):p*=BB[i][j]
  target+=p
 b=reduce(target,False)
 data=dict(status='EXACT_POLYNOMIAL_IDENTITIES_VERIFIED',rank=len(basis),labels=labels,basis=[dump_poly(p) for p in basis],F=[[str(col.get(i,0)) for col in features] for i in range(len(basis))],b=[str(b.get(i,0)) for i in range(len(basis))],target=dump_poly(target))
 (P/'exact_pure_features.json').write_text(json.dumps(data,separators=(',',':')))
 print('Target represented exactly; rank',len(basis),'seconds',time.time()-t,flush=True)
