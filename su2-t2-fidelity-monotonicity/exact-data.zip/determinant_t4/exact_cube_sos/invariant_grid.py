"""Prove that a finite evaluation grid detects every relevant invariant.

Degree-five SU(2) invariants even under conjugation have dimension 432.
Construct invariant contractions and prove a 432-column evaluation minor is
nonzero modulo a prime. This is an exact injectivity certificate over Q.
"""
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
from itertools import combinations_with_replacement
from math import comb
import json,time,numpy as np
from flint import fmpq,nmod_mat
from sympy import isprime,sqrt_mod
P=Path(__file__).resolve().parent;prime=1000033
def moment_forms():
 out={}
 for ell in range(6):
  row={a*6+a+ell:fmpq(comb(5-ell,a)) for a in range(6-ell)};out[ell]=[row]
  for k in range(2*ell):
   new=defaultdict(fmpq)
   for h,v in row.items():
    a,b=divmod(h,6)
    if a<5:new[(a+1)*6+b]+=(5-a)*v
    if b:new[a*6+b-1]-=b*v
   row={h:v/(2*ell-k) for h,v in new.items() if v};out[ell].append(row)
 return out
@lru_cache(None)
def coupling(r,s,L):
 k=r+s-L;row={(i,k-i):fmpq((-1)**i*comb(k,i)) for i in range(k+1)};out=[row]
 for m in range(2*L):
  new=defaultdict(fmpq)
  for (i,j),v in row.items():
   if i<2*r:new[i+1,j]+=(2*r-i)*v
   if j<2*s:new[i,j+1]+=(2*s-j)*v
  row={key:v/(2*L-m) for key,v in new.items() if v};out.append(row)
 return out
def ratmod(v):return int(v.numerator)%prime*pow(int(v.denominator),-1,prime)%prime
def couple(a,b,r,s,L):
 return np.array([sum((ratmod(v)*((a[i]*b[j])%prime)%prime for (i,j),v in row.items()),np.zeros(a.shape[1],np.int64))%prime for row in coupling(r,s,L)])
if __name__=='__main__':
 assert isprime(prime);root=int(sqrt_mod(-1,prime));rng=np.random.default_rng(53872);n=432
 hr=rng.integers(-2,3,size=(n,6,6),dtype=np.int64);hi=rng.integers(-2,3,size=(n,6,6),dtype=np.int64)
 for a in range(6):
  hi[:,a,a]=0
  for b in range(a+1,6):hr[:,b,a]=hr[:,a,b];hi[:,b,a]=-hi[:,a,b]
 H=(hr+root*hi)%prime;hm=H.reshape(n,36).T;mom={ell:np.array([sum((ratmod(v)*hm[h]%prime for h,v in row.items()),np.zeros(n,np.int64))%prime for row in forms]) for ell,forms in moment_forms().items()}
 pair={};triple={};values=[];labels=[];start=time.time()
 for a,b,c,d,e in combinations_with_replacement(range(6),5):
  if (a+b+c+d+e)%2:continue
  for u in range(b-a,a+b+1):
   if a==b and (a+b-u)%2:continue
   key=(a,b,u)
   if key not in pair:pair[key]=couple(mom[a],mom[b],a,b,u)
   for v in range(d-c,c+d+1):
    if c==d and (c+d-v)%2:continue
    if not abs(v-e)<=u<=v+e:continue
    key2=(c,d,v)
    if key2 not in pair:pair[key2]=couple(mom[c],mom[d],c,d,v)
    key3=(c,d,v,e,u)
    if key3 not in triple:triple[key3]=couple(pair[key2],mom[e],v,e,u)
    z=sum((((-1)**i*comb(2*u,i)%prime)*((pair[key][i]*triple[key3][2*u-i])%prime)%prime for i in range(2*u+1)),np.zeros(n,np.int64))%prime
    values.append(z);labels.append([a,b,u,c,d,v,e])
 print('Invariant candidates',len(values),'seconds',time.time()-start,flush=True)
 A=np.array(values).T;M=nmod_mat(A.tolist(),prime);RR,rank=M.rref();assert rank==432,rank
 piv=[next(j for j in range(RR.ncols()) if RR[i,j]) for i in range(rank)];minor=nmod_mat(A[:,piv].tolist(),prime);det=int(minor.det());assert det
 D={(0,0,0):1}
 for ell in range(6):
  for m in range(-ell,ell+1):
   new=defaultdict(int)
   for (deg,w,p),val in D.items():
    for k in range(6-deg):new[deg+k,w+k*m,(p+k*ell)%2]+=val
   D=new
 dim=D[5,0,0]-D[5,1,0];assert dim==rank
 report=dict(status='EXACT_INVARIANT_EVALUATION_INJECTIVITY_VERIFIED',degree=5,even_invariant_dimension=dim,prime=prime,sqrt_minus_one=root,minor_determinant=det,selected_contractions=[labels[i] for i in piv],real=hr.tolist(),imag=hi.tolist())
 (P/'invariant_grid_certificate.json').write_text(json.dumps(report,separators=(',',':')));np.savez(P/'invariant_grid.npz',real=hr,imag=hi)
 print('Exact grid rank',rank,'nonzero determinant mod prime',det,'seconds',time.time()-start,flush=True)
