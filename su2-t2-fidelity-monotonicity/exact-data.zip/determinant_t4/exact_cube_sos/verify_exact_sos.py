"""Standalone exact verifier. No SDP solver or numerical candidate is used.

Dependencies: python-flint, numpy, sympy. All certificate decisions use exact
integer/rational arithmetic. The modular determinant is an exact rank proof.
"""
from pathlib import Path
from collections import defaultdict
from math import comb,lcm
import json,time,numpy as np
from flint import fmpq,fmpq_mat,nmod_mat
from exact_evaluate import Evaluator
from invariant_grid import moment_forms,couple,prime,ratmod
P=Path(__file__).resolve().parent
def act(row,sign,source):
 out=defaultdict(int)
 for (mon,c),v in row.items():
  for pos,h in enumerate(mon):
   a,b=divmod(h,6);moves=[(a+1,b,5-a),(a,b-1,-b)] if sign==1 else [(a-1,b,a),(a,b+1,-(5-b))]
   for aa,bb,m in moves:
    if m:new=list(mon);new[pos]=aa*6+bb;out[tuple(sorted(new)),c]+=m*v
  ds=[c] if source==1 else [c//36,c//6%6,c%6]
  for pos,h in enumerate(ds):
   m=5-h if sign==1 else h
   if m:
    new=ds.copy();new[pos]+=sign;cc=new[0] if source==1 else new[0]*36+new[1]*6+new[2];out[mon,cc]+=m*v
 return {k:v for k,v in out.items() if v}
def verify_covariants():
 src=json.loads((P/'source_bases.json').read_text());total=0
 for k in range(35):
  d=json.loads((P/f'exact_reduced_basis_{k}.json').read_text());S=src[d['kind']]['matrix'];source=1 if d['kind']=='rho' else 3;degree=2 if source==1 else 1;J=d['J2'];support=[[(i,v) for i,v in enumerate(row) if v] for row in S]
  for q in d['Q_integer']:
   lifted=[]
   for r,row in enumerate(q):
    Q=defaultdict(int)
    for mon,c,v in row:
     assert len(mon)==degree
     for cc,w in support[c]:Q[tuple(mon),cc]+=int(v)*w
    Q={key:v for key,v in Q.items() if v}
    for (mon,c),v in Q.items():
     ds=[c] if source==1 else [c//36,c//6%6,c%6]
     assert sum(2*(h%6-h//6) for h in mon)+5*source-2*sum(ds)==J-2*r
    lifted.append(Q)
   for r,row in enumerate(lifted):
    up={key:(J-r)*v for key,v in lifted[r+1].items()} if r<J else {}
    dn={key:r*v for key,v in lifted[r-1].items()} if r else {}
    assert act(row,1,source)==up,('covariance +',k,r)
    assert act(row,-1,source)==dn,('covariance -',k,r)
   total+=1
  print('Exact covariance verified for block',k,flush=True)
 return total
def verify_channel():
 import sympy as s
 from sympy.physics.wigner import clebsch_gordan as cg
 j=s.Rational(5,2);K=[s.Matrix(6,6,lambda r,c:cg(j,2,j,j-c,q,j-r)) for q in range(-2,3)]
 assert sum((A.T*A for A in K),s.zeros(6))==s.eye(6)
 D5=s.diag(*(s.sqrt(s.binomial(5,a)) for a in range(6)));D4i=s.diag(*(1/s.sqrt(s.binomial(4,a)) for a in range(5)));maps=[]
 for b in range(2):
  F=s.zeros(5,6)
  for a in range(5):F[a,a+b]=s.sqrt(s.binomial(4,a)/s.binomial(5,a+b))
  maps.extend(D4i*F*A*D5 for A in K)
 expected={(r,c,a,b):s.Rational(v) for r,c,a,b,v in json.loads((P.parent/'coherent_sos/channel_rational.json').read_text())}
 for r in range(5):
  for c in range(5):
   for a in range(6):
    for b in range(6):assert s.simplify(sum(M[r,a]*M[c,b] for M in maps))==expected.get((r,c,a,b),0)
 return True
def verify_grid():
 d=json.loads((P/'invariant_grid_certificate.json').read_text());assert d['prime']==prime;root=d['sqrt_minus_one'];assert root*root%prime==prime-1
 H=(np.array(d['real'],dtype=np.int64)+root*np.array(d['imag'],dtype=np.int64))%prime;n=len(H);hm=H.reshape(n,36).T;mom={ell:np.array([sum((ratmod(v)*hm[h]%prime for h,v in row.items()),np.zeros(n,np.int64))%prime for row in forms]) for ell,forms in moment_forms().items()};pair={};triple={};values=[]
 for a,b,u,c,e2,v,e in d['selected_contractions']:
  assert (a+b+c+e2+e)%2==0
  for r,s,L in [(a,b,u),(c,e2,v)]:
   assert abs(r-s)<=L<=r+s
   if (r,s,L) not in pair:pair[r,s,L]=couple(mom[r],mom[s],r,s,L)
  assert abs(v-e)<=u<=v+e;key=(c,e2,v,e,u)
  if key not in triple:triple[key]=couple(pair[c,e2,v],mom[e],v,e,u)
  values.append(sum((((-1)**i*comb(2*u,i)%prime)*((pair[a,b,u][i]*triple[key][2*u-i])%prime)%prime for i in range(2*u+1)),np.zeros(n,np.int64))%prime)
 determinant=int(nmod_mat(np.array(values).T.tolist(),prime).det());assert determinant==d['minor_determinant'] and determinant
 D={(0,0,0):1}
 for ell in range(6):
  for m in range(-ell,ell+1):
   E=defaultdict(int)
   for (degree,w,p),v in D.items():
    for k in range(6-degree):E[degree+k,w+k*m,(p+k*ell)%2]+=v
   D=E
 assert D[5,0,0]-D[5,1,0]==n==432
 return d
def verify_grams(cert):
 g0=[];delta={int(k):fmpq(v) for k,v in cert['corrections'].items()};off=0;minimum=None;uppermax=fmpq(0);lower_min=None
 for block in cert['blocks']:
  n=block['dimension'];L=fmpq_mat([[fmpq(v)/fmpq(cert['L_denominator']) for v in row] for row in block['L_integer']]);G=L*L.transpose();iv=L.inv();norm=sum((v*v for v in iv.entries()),fmpq(0));lower=fmpq(block['baseline_lower_bound']);upper=fmpq(block['correction_upper_bound']);assert lower>upper>=0 and lower*norm<=1;E=fmpq_mat(n,n)
  for i in range(n):
   for j in range(i,n):E[i,j]=E[j,i]=delta.get(off,fmpq(0));g0.append(G[i,j]);off+=1
  assert max(sum((abs(E[i,j]) for j in range(n)),fmpq(0)) for i in range(n))<=upper
  assert lower-upper==fmpq(block['positive_margin']);minimum=lower-upper if minimum is None else min(minimum,lower-upper);uppermax=max(uppermax,upper);lower_min=lower if lower_min is None else min(lower_min,lower)
 assert lower_min==fmpq(1,65536) and uppermax<=fmpq(1,274877906944)
 return g0,delta,minimum
if __name__=='__main__':
 start=time.time();cert=json.loads((P/'exact_sos_certificate.json').read_text());assert cert['status']=='EXACT_WEIGHTED_SOS_CERTIFICATE_VERIFIED';verify_channel();print('Exact K=2 channel map verified',flush=True)
 count=verify_covariants();assert count==482
 grid=verify_grid();print('Exact invariant grid injectivity verified',flush=True)
 g0,delta,minimum=verify_grams(cert);print('All 35 Gram matrices certified positive',flush=True)
 ev=Evaluator();assert ev.dimensions==cert['gram_dimensions'];base=[g/d for g,d in zip(g0,ev.denoms)];bc=lcm(140**5,*(int(v.denominator) for v in base));bi=[int(v*bc) for v in base];corr={k:v/ev.denoms[k] for k,v in delta.items()};dc=lcm(*(int(v.denominator) for v in corr.values()));ci={k:int(v*dc) for k,v in corr.items()}
 for k,(hr,hi) in enumerate(zip(grid['real'],grid['imag'])):
  row,y=ev.evaluate(np.array(hr,dtype=np.int64),np.array(hi,dtype=np.int64));target=fmpq(y);assert (target*bc).denominator==1;res=int(target*bc)-sum(v*w for v,w in zip(row,bi));cor=sum(row[j]*v for j,v in ci.items());assert res*dc==cor*bc,('exact identity failed',k)
  if k%40==0:print('Exact identity verified at grid point',k,'seconds',time.time()-start,flush=True)
 report=dict(status='PASS_EXACT_WEIGHTED_SOS_PROOF',channel_verified=True,covariants=count,positive_gram_blocks=35,minimum_certified_gram_eigenvalue=str(minimum),uniform_bound='G >= (2^-16 - 2^-38) I > 2^-17 I',exact_grid_points=432,invariant_dimension=432,nonzero_evaluation_minor_mod_prime=grid['minor_determinant'],all_mixed_inputs=True,elapsed_seconds=time.time()-start)
 (P/'exact_sos_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
