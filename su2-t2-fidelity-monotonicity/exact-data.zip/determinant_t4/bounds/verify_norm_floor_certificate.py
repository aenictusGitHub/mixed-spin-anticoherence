"""Independent verifier: reads only saved certificates; no LP or search calls."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import isqrt
import sys,json
import sympy as s
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common_multipliers import globalG,fexact
PTH=Path(__file__).parent
C2=(F(2,5),F(2,7),F(1,2),F(18,35));CF=F(25,3)

def rat(x):
 x=s.simplify(x);assert x.is_Rational
 return F(int(x.p),int(x.q))
def log_enclosure(x,n):
 assert x>0
 if x<1:
  lo,hi=log_enclosure(1/x,n);return -hi,-lo
 exponent=0
 while x>=2:x/=2;exponent+=1
 def enclose(q):
  total=F(0);power=q
  for j in range(n):total+=2*power/F(2*j+1);power*=q*q
  return total,total+2*power/(F(2*n+1)*(1-q*q))
 low,high=enclose((x-1)/(x+1));l2,u2=enclose(F(1,3))
 return low+exponent*l2,high+exponent*u2

def sharp_upper(m,variance,terms,scale):
 assert 0<m<=F(1,5) and variance>=0
 if m==F(1,5) or not variance:return F(0)
 if variance>=F(4,5)*(1-5*m)**2:
  return log_enclosure(1/(3125*m**4*(1-4*m)),terms)[1]
 values=[]
 for k in range(4):
  q=5-k;S=1-k*m;Q=F(1,5)+variance-k*m*m;D=q*Q-S*S
  if D<0:continue
  v=(q-1)*D;rl=F(isqrt(v.numerator*scale*scale//v.denominator),scale)
  assert rl*rl<=v<(rl+F(1,scale))**2
  if (S-rl)/q<m:continue
  b=max(m,(S-rl-F(1,scale))/q)
  v=D/F(q-1);rl=F(isqrt(v.numerator*scale*scale//v.denominator),scale)
  assert rl*rl<=v<(rl+F(1,scale))**2
  a=max(m,(S+rl)/q)
  values.append(log_enclosure(1/(3125*m**k*b*a**(q-1)),terms)[1])
 assert values
 return max(values)

def check_file(path):
 data=json.loads(path.read_text());assert data['complete'] and data['queue_remaining']==0
 N,K=data['N'],data['K'];terms=data['log_terms'];scale=data['sqrt_scale']
 c2=tuple(map(F,data['c2']));assert c2==C2
 f=tuple(map(F,data['f']));assert f==tuple(rat(fexact(N,K,l)) for l in range(1,5));ff=tuple(x*x for x in f)
 G=[tuple(rat(q) for q in col) for col in zip(*globalG(N,4,exact=True))]
 bh={
  'BH1':tuple(rat((-1-s.Rational(2,3)*(-1)**l*fexact(4,1,l))/s.Rational(10,3)) for l in range(1,5)),
  'BH2':tuple(rat((-1-s.Rational(4,5)*(-1)**l*(s.Rational(9,10)*fexact(4,1,l)+s.Rational(1,10)*fexact(4,3,l)))/s.Rational(16,5)) for l in range(1,5)),
  'BH3':tuple(rat((-1-(-1)**l*(s.Rational(484,625)*fexact(4,1,l)+s.Rational(6,625)*fexact(4,3,l)))/s.Rational(402,125)) for l in range(1,5))}
 P=[tuple(map(F,row)) for row in data['positive_columns']]
 for label,v in zip(data['positive_labels'],P):
  name,q=label;g=G[q]
  if name in ['G','TG']:expected=g
  elif name in ['BH1','TBH1','BH2','TBH2','BH3','TBH3']:expected=tuple(a*b for a,b in zip(g,bh[name.removeprefix('T')]))
  elif name=='globalBH':
   assert N%2;expected=tuple(g[l]*(F(0) if l%2==0 else -F(2,N-1)) for l in range(4))
  else:raise AssertionError(name)
  if name.startswith('T'):expected=tuple(-a if l%2==0 else a for l,a in enumerate(expected))
  assert v==expected
 physical=P+[(F(1),)*4];psq=[tuple(x*x for x in row) for row in physical]
 amax=tuple(map(F,data['amax']));full=tuple(c2[l]/max(abs(row[l]) for row in physical) for l in range(4))
 cap=F(data.get('quad_cap','1'));assert 0<cap<=1
 assert amax==tuple(min(a,F(2,7)*cap) if l==1 else a for l,a in enumerate(full))
 lin=[]
 for row in psq:
  for co,rhs in [((0,8,5,1),F(14,5)),((5,-3,0,4),F(6,5))]:lin.append((tuple(a*b for a,b in zip(co,row)),rhs))
 if 'linear_constraints' in data:
  assert lin==[(tuple(map(F,r['coefficients'])),F(r['rhs'])) for r in data['linear_constraints']]
 # Reconstruct each exact feasible multiplier decomposition.
 bases=[];npcol=len(P)
 for b in data['bases']:
  ids=b['indices'];w=tuple(map(F,b['weights']));assert len(ids)==len(w) and min(w)>=0
  actual=[F(0)]*4;weight=F(0);residual=[F(0)]*4
  for i,ww in zip(ids,w):
   if i<npcol:
    weight+=ww
    for l in range(4):actual[l]+=ww*P[i][l]
   elif i<npcol+4:actual[i-npcol]+=ww;residual[i-npcol]+=ww
   else:actual[i-npcol-4]-=ww;residual[i-npcol-4]+=ww
  assert tuple(actual)==f
  beta0=(1-weight)/5;beta=tuple(-x for x in residual)
  assert beta0==F(b['beta0']) and beta==tuple(map(F,b['beta']))
  bases.append((beta0,beta))
 # Reconstruct the exact dyadic partition as a binary tree.
 tree={};counts={}
 for row in data['boxes']:
  lo=tuple(map(F,row['lo']));hi=tuple(map(F,row['hi']));kind=row['kind'];idx=row['data']
  levels=[];positions=[]
  for j in range(4):
   assert 0<=lo[j]<hi[j]<=amax[j]
   width=(hi[j]-lo[j])/amax[j];assert width.numerator==1
   den=width.denominator;assert den&(den-1)==0
   level=den.bit_length()-1;pos=lo[j]/(hi[j]-lo[j]);assert pos.denominator==1
   levels.append(level);positions.append(int(pos))
  depth=sum(levels);assert levels==[(depth+3-j)//4 for j in range(4)]
  node=tree;used=[0]*4
  for step in range(depth):
   assert 'leaf' not in node
   axis=step%4;bit=(positions[axis]>>(levels[axis]-1-used[axis]))&1;used[axis]+=1
   node=node.setdefault(bit,{})
  assert not node;node['leaf']=True
  vl=tuple(x*x/c for x,c in zip(lo,c2));vh=tuple(x*x/c for x,c in zip(hi,c2));counts[kind]=counts.get(kind,0)+1
  if kind=='pure_or_empty':assert sum(vl)>=F(4,5);continue
  if kind=='sector_pure_or_empty':assert F(5,2)*lo[0]>=1 or F(7,2)*lo[1]>=1 or vl[0]+vl[2]>=F(1,2);continue
  if kind=='empty':assert sum(x*y for x,y in zip(psq[idx],vl))>F(4,5);continue
  if kind=='linear_empty':
   co,rhs=lin[idx];assert sum(a*(vl[j] if a>=0 else vh[j]) for j,a in enumerate(co))>rhs;continue
  if kind=='norm_empty':
   g=tuple(abs(q) for q in physical[idx//3]);which=idx%3
   if which==0:
    point=max(g[1]*lo[1],min(F(3,98),g[1]*hi[1]))
    assert 245*point*point-15*point-14>20*g[3]*hi[3]
   elif which==1:assert 25*(g[0]*lo[0])**2>2+7*g[1]*hi[1]
   else:
    left=15*g[0]*lo[0]-5;right=2*g[2]*hi[2]
    assert left>0 and left*left>5*right*right
   continue
  basis_id=idx['basis'] if kind in ['mixed_linear','sharp_absolute'] else idx
  b0,beta=bases[basis_id];m=b0+sum(a*b for a,b in zip(beta,hi));assert 0<m<=F(1,5)
  C=F(25,2) if m==F(1,5) else 20*log_enclosure(256/(3125*m*(1-m)**4),terms)[1]/(1-5*m)**2
  if kind=='sharp_absolute':
   p1=F(5,2)*lo[0];p2=F(7,2)*lo[1];w=vl[0]+vl[2]
   assert p1<1 and p2<1 and w<F(1,2)
   x=F(idx['quad_x']);t=F(idx['odd_t'])
   assert 0<=x<1 and t>=0 and x*p2<1 and 2*w*t*t<1 and 2*w*t<1
   lower=max(log_enclosure((1-p1*p1/4)/(1-p1*p1)**4,terms)[0],
             log_enclosure((1+p2/2)**2/((1-p2)**3*(1+p2)**4),terms)[0],
             log_enclosure(1/(1-2*w)**4,terms)[0],
             log_enclosure((1-x)**2*(1+x)*(1+x/2)**2/(1-x*p2)**5,terms)[0],
             log_enclosure((1-2*w*t*t)/(1-2*w*t)**5,terms)[0],
             CF*sum(vl),F(25,2)*vl[0],12*vl[1],12*w)
   v=sum(vl)
   if v:
    arg=F(4,5)*v;rl=F(isqrt(arg.numerator*scale*scale//arg.denominator),scale)
    a=F(1,5)+rl;lower=max(lower,log_enclosure(256/(3125*a*(1-a)**4),terms)[0])
   assert sharp_upper(m,sum(a*b for a,b in zip(ff,vh)),terms,scale)<=lower
  elif kind=='mixed_linear':
   weights=tuple(map(F,idx['weights']));assert len(weights)==4 and min(weights)>=0 and sum(weights)==1
   forms=((CF,CF,CF,CF),(F(25,2),F(0),F(0),F(0)),(F(0),F(12),F(0),F(0)),(F(12),F(0),F(12),F(0)))
   coeff=tuple(sum(weights[i]*forms[i][j] for i in range(4))-C*ff[j] for j in range(4))
   assert sum(min(a*l,a*h) for a,l,h in zip(coeff,vl,vh))>=0
  elif kind in ['ratio','dipole_ratio']:
   candidates=[tuple((vh if bit else vl)[j] for j,bit in enumerate(bits)) for bits in product([0,1],repeat=4)]
   if kind=='dipole_ratio':
    for axis in range(4):
     other=[j for j in range(4) if j!=axis]
     for bits in product([0,1],repeat=3):
      v=[F(0)]*4
      for j,bit in zip(other,bits):v[j]=(vh if bit else vl)[j]
      v[axis]=2*sum(v[1:]) if axis==0 else v[0]/2-sum(v[j] for j in range(1,4) if j!=axis)
      if vl[axis]<=v[axis]<=vh[axis]:candidates.append(tuple(v))
   for v in candidates:
    if not sum(v):continue
    lower=CF*sum(v) if kind=='ratio' else max(CF*sum(v),F(25,2)*v[0])
    assert C*sum(a*b for a,b in zip(ff,v))<=lower
  elif kind=='sector_absolute':
   p1=F(5,2)*lo[0];p2=F(7,2)*lo[1];w=vl[0]+vl[2]
   assert p1<1 and p2<1 and w<F(1,2)
   lower=max(log_enclosure((1-p1*p1/4)/(1-p1*p1)**4,terms)[0],
             log_enclosure((1+p2/2)**2/((1-p2)**3*(1+p2)**4),terms)[0],
             log_enclosure(1/(1-2*w)**4,terms)[0])
   assert C*sum(x*y for x,y in zip(ff,vh))<=lower
  elif kind=='absolute':
   v=sum(vl);assert 0<v<F(4,5)
   arg=F(4,5)*v;root=F(isqrt(arg.numerator*scale*scale//arg.denominator),scale)
   assert root*root<=arg<(root+F(1,scale))**2
   a=F(1,5)+root;lower=log_enclosure(256/(3125*a*(1-a)**4),terms)[0]
   assert C*sum(x*y for x,y in zip(ff,vh))<=lower
  else:raise AssertionError(kind)
 def covered(node):
  if 'leaf' in node:assert node=={'leaf':True};return
  assert set(node)=={0,1};covered(node[0]);covered(node[1])
 covered(tree)
 print('VERIFIED',N,K,len(data['boxes']),'leaves',counts,flush=True)

paths=[Path(p) for p in sys.argv[1:]] if len(sys.argv)>1 else sorted(PTH.glob('norm_floor_certificate_N*_K*.json'))
for path in paths:check_file(path)
