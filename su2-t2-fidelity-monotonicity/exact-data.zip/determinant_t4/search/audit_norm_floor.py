"""Independent exact audit of saved t4 norm-floor box certificates.
No numerical LP is used. CG channels, positive generators, all rational
weights, leaf predicates, and deterministic bisection coverage are rechecked.
Log bounds use20 terms and sqrt bounds2^48, independently tighter than the
12-term/2^40 authoring bounds.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt,comb
from itertools import product
import json,sympy as S
from sympy.physics.wigner import clebsch_gordan,wigner_6j
OUT=Path(__file__).resolve().parent;BD=OUT.parent/'bounds'
C2=tuple(map(F,['2/5','2/7','1/2','18/35']));CF=F(25,3);FLIP=(-1,1,-1,1)
def ff(x):
 x=S.simplify(x);assert x.is_Rational;return F(int(x.p),int(x.q))
def multipliers(N,K):
 j=S.Rational(N,2);return tuple(ff((-1)**(N+K+l)*(N+1)*wigner_6j(j,j,l,j,j,K)) for l in range(1,5))
# Verify explicit skew contractions underlying the two local positive maps.
Jp=S.zeros(5)
for k in range(1,5):Jp[k-1,k]=S.sqrt(k*(5-k))
Jz=S.diag(2,1,0,-1,-2);V=S.zeros(5)
for k in range(5):V[k,4-k]=(-1)**k
A1=Jp*V/S.sqrt(6);D=S.diag(1,1,0,-1,-1);A2=D*V
for A in [A1,A2]:
 assert A.T==-A
 eig=(S.eye(5)-A*A.H).eigenvals();assert all(z>=0 for z in eig)
assert S.trace(A1*A1.H)/5==S.Rational(2,3)
assert S.trace(A2*A2.H)/5==S.Rational(4,5)
# A1 is a rank1 tensor times V. A2 V*=D is odd, hence ranks1 and3 only.
assert V*D.T*V.T==-D
rank1norm=S.simplify(S.trace(D*Jz)**2/S.trace(Jz*Jz));total=S.trace(D*D)
assert rank1norm/total==S.Rational(9,10)
f1=multipliers(4,1);f3=multipliers(4,3)
BH1=tuple((-1-F(2,3)*FLIP[l]*f1[l])/F(10,3) for l in range(4))
BH2=tuple((-1-F(4,5)*FLIP[l]*(F(9,10)*f1[l]+F(1,10)*f3[l]))/F(16,5) for l in range(4))
# Third skew contraction, independently checked before accepting its columns.
D3=S.zeros(5)
for k,w in enumerate([1,2*S.sqrt(6)/5,2*S.sqrt(6)/5,1]):D3[k,k+1]=w
A3=D3*V
assert A3.T==-A3 and all(x>=0 for x in (S.eye(5)-A3*A3.H).eigenvals())
assert S.trace(D3*D3.H)/5==S.Rational(98,125)
assert V*D3.T*V.T==-D3
assert S.simplify(S.trace(Jp.H*D3)**2/S.trace(Jp.H*Jp)/5)==S.Rational(484,625)
BH3=tuple((-1-FLIP[l]*(F(484,625)*f1[l]+F(6,625)*f3[l]))/F(402,125) for l in range(4))
# Rebuild exact tensors to validate Fierz pruning and the nonlinear constraints.
T={}
for l in range(5):
 for q in range(-l,l+1):
  T[l,q]=S.Matrix(5,5,lambda r,c:S.sqrt(S.Rational(2*l+1,5))*clebsch_gordan(2,l,2,2-c,q,2-r))
  assert S.simplify(S.trace(T[l,q].H*T[l,q]))==1
QQ={l:sum((S.kronecker_product(T[l,q],T[l,q].H) for q in range(-l,l+1)),S.zeros(25)) for l in [1,2]}
PP={}
for J in [0,1,3]:
 PP[J]=S.zeros(25)
 for M in range(-J,J+1):
  w=S.Matrix([clebsch_gordan(2,2,J,2-r,2-c,M) for r in range(5) for c in range(5)])
  PP[J]+=w*w.T
assert S.simplify(QQ[2]-S.Rational(5,7)*QQ[1]-S.Rational(10,7)*PP[0]-S.Rational(6,7)*PP[1]+S.Rational(4,7)*PP[3])==S.zeros(25)
qa,qb=S.symbols('qa qb',real=True);Q=qa*T[2,0]+qb*(T[2,2]+T[2,-2])/S.sqrt(2);u=qa**2+qb**2
qnorms=[]
for l in range(5):
 qnorms.append(S.simplify(sum(S.expand_complex(S.trace(T[l,q].H*Q*Q)*S.conjugate(S.trace(T[l,q].H*Q*Q))) for q in range(-l,l+1))))
assert all(S.expand(a-b)==0 for a,b in zip(qnorms,[u**2/5,0,9*u**2/686,0,72*u**2/1715]))
assert Jz*Jz==2*S.eye(5)+S.sqrt(14)*T[2,0]
assert all(x>=0 for x in (S.Rational(5,3)*S.eye(5)-Jz+S.sqrt(10)*T[3,0]/3).eigenvals())
rr=S.symbols('rr',real=True);xx=rr**2
normdef=sum(S.Rational(2,5)/(2+rr**2-rr*m) for m in range(-2,3))-1
assert S.factor(normdef+xx**2*(5*xx**3+15*xx**2+20*xx+12)/(5*(xx+2)*(xx**2+4)*(xx**2+3*xx+4)))==0
# Linear quadrupole and odd-sector Burg bounds: verify exact algebra in their
# stationary-point proofs, independently of their companion check scripts.
zz,ll,tt=S.symbols('zz ll tt',real=True)
qprod=qa*(qa*qa-3*qb*qb)/(7*S.sqrt(14))
assert S.simplify((ll*S.eye(5)-tt*Q).det()-(ll*ll-2*tt*tt*u/7)*(ll**3-3*tt*tt*u*ll/14-tt**3*qprod))==0
quaddef=2/(336*zz**2-48*zz+5)+2/(336*zz**2+24*zz+5)+1/(336*zz**2+48*zz+5)-1
quadnum=48*zz**2*(790272*zz**4+56448*zz**3+7392*zz**2-312*zz+7)
quadden=(336*zz**2-48*zz+5)*(336*zz**2+24*zz+5)*(336*zz**2+48*zz+5)
assert S.factor(quaddef+quadnum/quadden)==0 and 312**2-4*7392*7<0
ar=F(2059,8309);assert 2*(ar+ar**3/3)>F(1,2)
# Nonlinear sector bounds follow from matrix AM-GM. Their scalar forms are
# increasing, allowing lower corners to replace the actual sector norm.
pp=S.symbols('pp',positive=True)
bqprime=S.factor(3/(1-pp)-4/(1+pp)+1/(1+pp/2))
assert S.simplify(bqprime-pp*(5*pp+13)/((1-pp)*(1+pp)*(pp+2)))==0
# Fresh CG construction of rectangular-channel multipliers relative to reduction.
Gcache={};cgchecks=0

def gamma(N):
 global cgchecks
 if N in Gcache:return Gcache[N]
 j=S.Rational(N,2);a=S.Integer(2);d=N+1
 tins=[S.Matrix([clebsch_gordan(j,l,j,j-k,0,j-k) for k in range(d)]) for l in range(1,5)]
 imgs=[]
 for q in range(5):
  env=j-a+q
  B=S.zeros(5,d)
  for r in range(5):
   for k in range(d):
    mu=j-k-(a-r)
    if abs(mu)<=env:B[r,k]=clebsch_gordan(a,env,j,a-r,mu,j-k)**2
  assert all(S.simplify(sum(B[r,k] for r in range(5))-1)==0 for k in range(d))
  assert S.simplify(B*S.ones(d,1)-S.Rational(d,5)*S.ones(5,1))==S.zeros(5,1)
  if q==0:
   H=S.zeros(5,d)
   for b in range(N-3):
    for r in range(5):H[r,r+b]+=S.Rational(comb(4,r)*comb(N-4,b),comb(N,r+b))
   assert B==H
  imgs.append([S.simplify(B*t) for t in tins])
 G=[]
 for q in range(5):
  row=[]
  for l in range(4):
   ratio=S.simplify(imgs[q][l][0]/imgs[0][l][0]);assert S.simplify(imgs[q][l]-ratio*imgs[0][l])==S.zeros(5,1);row.append(ff(ratio));cgchecks+=1
  G.append(tuple(row))
 Gcache[N]=G;return G

def log_iv(x,terms=20):
 assert x>0
 if x<1:
  lo,hi=log_iv(1/x,terms);return -hi,-lo
 k=max(0,x.numerator.bit_length()-x.denominator.bit_length());r=x/(2**k)
 while r<1:k-=1;r*=2
 while r>=2:k+=1;r/=2
 def atanh(q):
  lo=sum((2*q**(2*i+1)/F(2*i+1) for i in range(terms)),F(0));tail=2*q**(2*terms+1)/(F(2*terms+1)*(1-q*q));return lo,lo+tail
 l2,u2=atanh(F(1,3));lo,hi=atanh((r-1)/(r+1));return k*l2+lo,k*u2+hi

def Cup(m):
 assert 0<m<=F(1,5)
 if m==F(1,5):return F(25,2)
 return 20*log_iv(256/(3125*m*(1-m)**4))[1]/(1-5*m)**2

def Lin(v):
 assert 0<v<F(4,5)
 arg=F(4,5)*v;scale=2**48;h=F(isqrt(arg.numerator*scale*scale//arg.denominator),scale);assert h*h<=arg<(h+F(1,scale))**2
 a=F(1,5)+h;assert F(1,5)<a<1
 return log_iv(256/(3125*a*(1-a)**4))[0]

def corners_ratio(vlo,vhi,f2):
 vals=[]
 for bits in product([False,True],repeat=4):
  p=[vhi[l] if bits[l] else vlo[l] for l in range(4)];den=sum(p)
  if den:vals.append(sum(f2[l]*p[l] for l in range(4))/den)
 return max(vals,default=F(0))

def combined_ratio(vlo,vhi,f2):
 # A linear fractional maximum on either half-box lies at a vertex;
 # the separating plane creates only intersections with original edges.
 corners=[tuple(vhi[l] if bit[l] else vlo[l] for l in range(4)) for bit in product([0,1],repeat=4)]
 weights=(F(1),F(-2),F(-2),F(-2))
 for ax in range(4):
  others=[l for l in range(4) if l!=ax]
  for bits in product([0,1],repeat=3):
   p=[F(0)]*4
   for l,b in zip(others,bits):p[l]=vhi[l] if b else vlo[l]
   p[ax]=-sum(weights[l]*p[l] for l in others)/weights[ax]
   if vlo[ax]<=p[ax]<=vhi[ax]:corners.append(tuple(p))
 return max((sum(a*b for a,b in zip(f2,p))/max(CF*sum(p),F(25,2)*p[0]) for p in corners if sum(p)),default=F(0))
reports=[];skipped=[]
for path in sorted(BD.glob('norm_floor_certificate_N*_K*.json')):
 doc=json.loads(path.read_text())
 if not doc['complete']:skipped.append(path.name);continue
 N,K=doc['N'],doc['K'];assert tuple(map(F,doc['c2']))==C2
 f=tuple(map(F,doc['f']));assert f==multipliers(N,K);f2=tuple(x*x for x in f);G=gamma(N)
 P=[]
 for label,q in doc['positive_labels']:
  assert 0<=q<5;g=G[q]
  if label=='G':p=g
  elif label=='TG':p=tuple(g[l]*FLIP[l] for l in range(4))
  elif label in ['BH1','TBH1','BH2','TBH2','BH3','TBH3']:
   bh={'BH1':BH1,'BH2':BH2,'BH3':BH3}[label.removeprefix('T')];p=tuple(g[l]*bh[l]*(FLIP[l] if label.startswith('T') else 1) for l in range(4))
  elif label=='globalBH':
   assert N%2==1
   p=tuple(g[l]*(F(0) if l%2==0 else -F(2,N-1)) for l in range(4))
  else:raise AssertionError(label)
  P.append(p)
 assert P==[tuple(map(F,p)) for p in doc['positive_columns']]
 physical=P+[(F(1),)*4];amax=tuple(C2[l]/max(abs(p[l]) for p in physical) for l in range(4));assert amax==tuple(map(F,doc['amax']))
 linear=[]
 for p in physical:
  for coeff,rhs in [((0,8,5,1),F(14,5)),((5,-3,0,4),F(6,5))]:linear.append((tuple(F(coeff[l])*p[l]**2 for l in range(4)),rhs))
 if 'linear_constraints' in doc:assert linear==[(tuple(map(F,r['coefficients'])),F(r['rhs'])) for r in doc['linear_constraints']]
 # a_l=c_l sqrt(v_l); duality gives |p_l|sqrt(v_l)<=c_l for every positiveoutput.
 npcol=len(P);bases=[]
 for rec in doc['bases']:
  ids=rec['indices'];ww=tuple(map(F,rec['weights']));assert len(ids)==len(ww) and len(set(ids))==len(ids) and all(w>=0 for w in ww)
  out=[F(0)]*4
  for i,w in zip(ids,ww):
   assert 0<=i<npcol+8
   if i<npcol:
    for l in range(4):out[l]+=w*P[i][l]
   elif i<npcol+4:out[i-npcol]+=w
   else:out[i-npcol-4]-=w
  assert tuple(out)==f
  b0=F(1,5)-sum((w/5 for i,w in zip(ids,ww) if i<npcol),F(0));beta=tuple(-sum((w for i,w in zip(ids,ww) if i in [npcol+l,npcol+4+l]),F(0)) for l in range(4))
  assert b0==F(rec['beta0']) and beta==tuple(map(F,rec['beta'])) and all(b<=0 for b in beta);bases.append((b0,beta))
 leaves={};kinds={};margins=[]
 for rec in doc['boxes']:
  lo=tuple(map(F,rec['lo']));hi=tuple(map(F,rec['hi']));assert all(0<=lo[l]<hi[l]<=amax[l] for l in range(4));key=(lo,hi);assert key not in leaves;leaves[key]=rec
  vlo=tuple(lo[l]**2/C2[l] for l in range(4));vhi=tuple(hi[l]**2/C2[l] for l in range(4));vmin=sum(vlo);kind=rec['kind'];kinds[kind]=kinds.get(kind,0)+1
  if kind=='pure_or_empty':assert vmin>=F(4,5)
  elif kind=='empty':
   p=physical[rec['data']];assert sum(p[l]**2*vlo[l] for l in range(4))>F(4,5)
  elif kind=='linear_empty':
   coeff,rhs=linear[rec['data']];assert sum(coeff[l]*(vlo[l] if coeff[l]>=0 else vhi[l]) for l in range(4))>rhs
  elif kind=='norm_empty':
   gi,typ=divmod(rec['data'],3);g=tuple(abs(x) for x in physical[gi]);a=tuple(g[l]*lo[l] for l in range(4));b=tuple(g[l]*hi[l] for l in range(4))
   if typ==0:
    x=max(a[1],min(F(3,98),b[1]));assert 245*x*x-15*x-14>20*b[3]
   elif typ==1:assert 25*a[0]**2>2+7*b[1]
   else:
    lhs=15*a[0]-5;assert lhs>0 and lhs*lhs>20*b[2]**2
  elif kind in ['ratio','dipole_ratio','absolute','mixed_linear','sector_absolute']:
   bid=rec['data']['basis'] if kind=='mixed_linear' else rec['data']
   b0,beta=bases[bid];m=b0+sum(beta[l]*hi[l] for l in range(4));C=Cup(m)
   if kind=='ratio':gap=CF-C*corners_ratio(vlo,vhi,f2)
   elif kind=='dipole_ratio':gap=1-C*combined_ratio(vlo,vhi,f2)
   elif kind=='mixed_linear':
    ww=tuple(map(F,rec['data']['weights']));assert len(ww)==4 and min(ww)>=0 and sum(ww)==1
    forms=((CF,)*4,(F(25,2),F(0),F(0),F(0)),(F(0),F(12),F(0),F(0)),(F(12),F(0),F(12),F(0)))
    coeff=tuple(sum(ww[k]*forms[k][l] for k in range(4))-C*f2[l] for l in range(4))
    gap=sum(coeff[l]*(vlo[l] if coeff[l]>=0 else vhi[l]) for l in range(4))
   elif kind=='sector_absolute':
    d=F(5,2)*lo[0];q=F(7,2)*lo[1];w=vlo[0]+vlo[2];assert 0<=d<1 and 0<=q<1 and 0<=w<F(1,2)
    lower=max(log_iv((1-d*d/4)/(1-d*d)**4)[0],log_iv((1+q/2)**2/((1-q)**3*(1+q)**4))[0],log_iv(1/(1-2*w)**4)[0])
    gap=lower-C*sum(f2[l]*vhi[l] for l in range(4))
   else:
    assert 0<vmin<F(4,5);gap=Lin(vmin)-C*sum(f2[l]*vhi[l] for l in range(4))
   assert gap>=0,(path.name,kind,float(gap));margins.append(gap)
  else:raise AssertionError(kind)
 assert doc['processed']==2*len(leaves)-1 and doc['queue_remaining']==0
 # Reconstruct authoring's deterministic bisection tree, detecting every gap.
 seen=set();nodes=0
 def cover(lo,hi,depth=0):
  global nodes
  nodes+=1;key=(lo,hi)
  if key in leaves:seen.add(key);return
  assert depth<52,(path.name,'coverage gap',lo,hi)
  ax=max(range(4),key=lambda l:(hi[l]-lo[l])/amax[l]);mid=(lo[ax]+hi[ax])/2;h=list(hi);h[ax]=mid;l=list(lo);l[ax]=mid
  cover(lo,tuple(h),depth+1);cover(tuple(l),hi,depth+1)
 cover((F(0),)*4,amax);assert seen==set(leaves) and nodes==doc['processed']
 report=dict(N=N,K=K,positive_columns=len(P),rational_floor_bases=len(bases),leaf_boxes=len(leaves),kinds=kinds,smallest_audited_scalar_gap=str(min(margins)) if margins else None);reports.append(report)
 print('PASSED',N,K,'leaves',len(leaves),'bases',len(bases),'kinds',kinds,flush=True)
result=dict(status='passed',certificates=reports,skipped_incomplete=skipped,CG_multiplier_comparisons=cgchecks,generator_proofs='All three explicit local skew contractions, their normalization and rank weights verified. Local and global spin reversals and all rectangular CG maps preserve positivity; norm-bound duality justifies domain bounds.',structural_checks='Exact full-matrix Fierz recoupling identity; quadrupole-square tensor projections; dipole variance and octupole operator bounds; stationary-point normalization identity for the dipole Burg bound.',coverage='Exact deterministic bisection-tree reconstruction; no gaps or omitted depth-failure boxes.',independent_log_terms=20,independent_sqrt_scale=2**48)
(OUT/'audit_norm_floor.json').write_text(json.dumps(result,indent=2));print('ALL_COMPLETE_CERTIFICATES_PASSED',len(reports),flush=True)
