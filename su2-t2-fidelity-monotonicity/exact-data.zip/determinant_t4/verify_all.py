"""Verify the exact order-four reduction and thirteen spectral-floor base cases.
The parent certificate suite also checks the exceptional (N,K)=(5,2) SOS case.
"""
from pathlib import Path
import subprocess,sys,json,time
ROOT=Path(__file__).resolve().parent
checks=[['structural/verify_burg_dimension5.py'],['structural/verify_spin2_operator_norms.py'],
['structural/verify_spin2_norm_constraints.py'],['structural/verify_dipole_burg_bound.py'],
['structural/verify_quadrupole_burg_bound.py'],['structural/verify_odd_burg_bound.py'],
['structural/verify_nonlinear_burg_bounds.py'],['structural/verify_k3_endpoint.py'],
['bounds/verify_norm_floor_certificate.py'],
['bounds/verify_norm_floor_certificate.py','bounds/compact_norm_floor_certificate_N5_K3.json','bounds/compact_norm_floor_certificate_N6_K3.json'],
['search/audit_norm_floor.py'],['structural/audit_k3_compact.py'],['structural/audit_finite_reduction.py'],
['structural/verify_von_neumann_t4_corollary.py']]
rows=[]
for args in checks:
 start=time.monotonic()
 p=subprocess.run([sys.executable]+[str(ROOT/x) for x in args],cwd=ROOT,capture_output=True,text=True)
 rows.append(dict(check=args,returncode=p.returncode,seconds=time.monotonic()-start,stdout=p.stdout,stderr=p.stderr))
 print(('PASS ' if p.returncode==0 else 'FAIL ')+args[0]+(' (compact K3)' if len(args)>1 else ''),flush=True)
 (ROOT/'verification_results.json').write_text(json.dumps(rows,indent=2)+'\n')
 if p.returncode:
  print(p.stdout,p.stderr,flush=True);raise SystemExit(p.returncode)
print('All thirteen spectral-floor certificates passed. The parent suite also checks the exceptional N=5, K=2 SOS certificate.',flush=True)
