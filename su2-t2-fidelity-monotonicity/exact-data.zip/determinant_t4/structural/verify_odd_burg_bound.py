from pathlib import Path
import sympy as s,json
lam,k=s.symbols('lambda k');b2=(lam*lam-24)/576
assert s.factor(12*(5+48*k*b2-lam))==k*lam*lam-12*lam+60-24*k
assert s.factor((lam*lam-12*lam+36))==(lam-6)**2
assert s.solve(2*lam*lam-12*lam+12,lam)==[3-s.sqrt(3),3+s.sqrt(3)]
assert s.simplify((6-s.sqrt(12))*(6+s.sqrt(12))*6**3)==5184
r=s.Rational(2059,8309);gap=s.factor(2*(r+r**3/3)-s.Rational(1,2));assert gap>0
out={'status':'PASS','bound':'L5 >= 12(v1+v3)','nonuniform_stationary_determinant':'1/5184','log_bound_rational_gap':str(gap)}
Path(__file__).with_name('odd_burg_bound_verification.json').write_text(json.dumps(out,indent=2));print(out)
