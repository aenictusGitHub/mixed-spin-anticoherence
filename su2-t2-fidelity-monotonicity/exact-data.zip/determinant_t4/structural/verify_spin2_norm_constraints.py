from pathlib import Path
import json,sympy as s
from sympy.physics.wigner import clebsch_gordan,wigner_6j
ms=[2,1,0,-1,-2]
def T(l,q):return s.Matrix([[s.sqrt(s.Rational(2*l+1,5))*clebsch_gordan(2,l,2,m,q,n) for m in ms] for n in ms])
a,b=s.symbols('a b',real=True);Q=a*T(2,0)+b*(T(2,2)+T(2,-2))/s.sqrt(2);u=a*a+b*b
assert s.simplify(s.trace(Q*Q)-u)==0
expected=[u*u/5,0,9*u*u/s.Integer(686),0,72*u*u/s.Integer(1715)]
for l in range(5):
 actual=sum(s.expand(s.trace(T(l,q).conjugate().T*Q*Q))**2 for q in range(-l,l+1))
 assert s.factor(actual-expected[l])==0
fierz=[s.factor((-1)**J*(5*wigner_6j(2,2,2,2,2,J)-s.Rational(15,7)*wigner_6j(2,2,1,2,2,J))-(s.Rational(10,7) if J==0 else 0)) for J in range(5)]
assert fierz==[0,s.Rational(6,7),0,-s.Rational(4,7),0]
v1,v2,v3,v4=s.symbols('v1 v2 v3 v4');P=s.Rational(1,5)+v1+v2+v3+v4;TT=s.Rational(1,5)-v1+v2-v3+v4
F=v2-s.Rational(5,7)*v1-s.Rational(2,7)*TT
assert s.expand(7*(F-s.Rational(3,7)*(1-P))-(8*v2+5*v3+v4-s.Rational(14,5)))==0
assert s.expand(-7*(F+s.Rational(2,7)*(1-P))-(5*v1+4*v4-3*v2-s.Rational(6,5)))==0
J=s.diag(*ms)
assert J*J==2*s.eye(5)+s.sqrt(14)*T(2,0)
assert J-s.sqrt(10)*T(3,0)/3==s.diag(s.Rational(5,3),s.Rational(5,3),0,-s.Rational(5,3),-s.Rational(5,3))
report={'status':'PASS','quadrupole_square_norms_squared':['u^2/5','0','9u^2/686','0','72u^2/1715'],'fierz_constraints':['8v2+5v3+v4<=14/5','5v1+4v4-3v2<=6/5'],'nonlinear_constraints':['245a2^2<=14+15a2+20a4','25a1^2<=2+7a2','15a1<=5+2sqrt(5)a3']}
Path(__file__).with_name('spin2_norm_constraints_verification.json').write_text(json.dumps(report,indent=2));print(report)
