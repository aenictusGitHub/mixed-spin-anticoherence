from pathlib import Path
import json,sympy as s
r,x=s.symbols('r x',real=True)
actual=sum(s.Rational(2,5)/(2+r*r-r*m) for m in range(-2,3))-1
expected=-x*x*(5*x**3+15*x*x+20*x+12)/(5*(x+2)*(x*x+4)*(x*x+3*x+4))
assert s.factor(actual-expected.subs(x,r*r))==0
out={'status':'PASS','normalization_defect':str(expected),'bound':'L5 >= (25/2) v1'}
Path(__file__).with_name('dipole_burg_bound_verification.json').write_text(json.dumps(out,indent=2));print(out)
