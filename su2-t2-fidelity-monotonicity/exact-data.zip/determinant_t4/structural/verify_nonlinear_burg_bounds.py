from pathlib import Path
import sympy as s,json
x,p,a=s.symbols('x p a',real=True)
assert s.expand((1-x*x)*(1-s.Rational(3,4)*x*x-x**3/4)-(1-x)**2*(1+x)*(1+x/2)**2)==0
assert s.expand((1-a*x*x)*(1-(1-a)*x*x)-(1-x*x+a*(1-a)*x**4))==0
# Check exponentiated forms to avoid assumptions about logarithm branch simplification.
BQ_exp=(1-p)**(-3)*(1+p)**(-4)*(1+p/2)**2
assert s.factor((1-p)**2*(1+p)*(1+p/2)**2/(1-p*p)**5-BQ_exp)==0
BD_exp=(1-p*p/4)/(1-p*p)**4
assert s.factor((1-p*p)*(1-p*p/4)/(1-p*p)**5-BD_exp)==0
assert s.factor((1-p*p)/(1-p*p)**5-(1-p*p)**(-4))==0
report={'status':'PASS','quadrupole':'-3log(1-p)-4log(1+p)+2log(1+p/2), p=sqrt(7v2/2)','dipole':'log(1-p^2/4)-4log(1-p^2), p=sqrt(5v1/2)','odd':'-4log(1-2(v1+v3))','method':'matrix arithmetic-geometric mean'}
Path(__file__).with_name('nonlinear_burg_bounds_verification.json').write_text(json.dumps(report,indent=2));print(report)
