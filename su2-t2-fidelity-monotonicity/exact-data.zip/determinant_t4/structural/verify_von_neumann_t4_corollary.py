from pathlib import Path
import sympy as s,json
from sympy.physics.wigner import wigner_6j
P=Path(__file__).parent;B=P.parent/'bounds'
bases=[(5,3),(5,4),(6,3),(6,4),(6,5),(7,4),(7,5),(7,6),(8,4),(8,7),(9,8),(10,9),(11,10)]
for N,K in bases:
 prefix='compact_' if (N,K) in [(5,3),(6,3)] else ''
 d=json.loads((B/f'{prefix}norm_floor_certificate_N{N}_K{K}.json').read_text())
 assert d['complete'] and d['queue_remaining']==0
 if prefix:assert s.Rational(d['quad_cap'])=={5:s.Rational(31,32),6:s.Rational(511,512)}[N]
N,K=5,2;j=s.Rational(5,2)
f=[s.simplify((-1)**(N+K+l)*(N+1)*wigner_6j(j,j,K,j,j,l)) for l in range(1,5)]
assert f==[s.Rational(23,35),s.Rational(1,10),-s.Rational(29,70),-s.Rational(1,2)]
assert max(q*q for q in f[1:])==s.Rational(1,4)
z=s.symbols('z',nonnegative=True);cross=s.Rational(7,18)
left=s.Rational(9,2)*(f[0]**2+z/4)/s.Rational(5,2)
right=s.Rational(9,2)*(f[0]**2+z/4)/(s.Rational(9,5)*(1+z))
assert s.diff(left,z)>0 and s.factor(s.diff(right,z)*(1+z)**2)<0
eta=s.Rational(46663,49000);assert left.subs(z,cross)==right.subs(z,cross)==eta<1
assert s.Rational(8,3)*(s.Rational(2,3)+s.Rational(2,81))>s.Rational(9,5)
assert 20*(s.Rational(1,4)-s.Rational(1,32)+s.Rational(1,192))<s.Rational(9,2)
out={'status':'PASS','order':4,'all_allowed_spins':True,'determinant_base_certificates':len(bases),'remaining_entropy_base':[5,2],'remaining_entropy_contraction':str(eta),'arbitrary_order_t_ge_5':'not proved'}
P.joinpath('von_neumann_t4_corollary_verification.json').write_text(json.dumps(out,indent=2));print(out)
