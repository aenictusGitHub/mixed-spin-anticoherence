from pathlib import Path
import sympy as s,json
from sympy.physics.wigner import clebsch_gordan
ms=[2,1,0,-1,-2]
def T(l,q):return s.Matrix([[s.sqrt(s.Rational(2*l+1,5))*clebsch_gordan(2,l,2,m,q,n) for m in ms] for n in ms])
a,b,la,t,z=s.symbols('a b lambda t z',real=True)
Q=a*T(2,0)+b*(T(2,2)+T(2,-2))/s.sqrt(2);u=a*a+b*b;q=a*(a*a-3*b*b)/(7*s.sqrt(14))
expected=(la*la-2*t*t*u/7)*(la**3-3*t*t*u*la/14-t**3*q)
assert s.factor((la*s.eye(5)-t*Q).det()-expected)==0
assert s.expand((a*a+b*b)**3-(a*(a*a-3*b*b))**2-b*b*(3*a*a-b*b)**2)==0
lam=5+336*z*z
actual=2/(lam-48*z)+2/(lam+24*z)+1/(lam+48*z)-1
P=790272*z**4+56448*z**3+7392*z*z-312*z+7
expected=-48*z*z*P/((lam-48*z)*(lam+24*z)*(lam+48*z))
assert s.factor(actual-expected)==0
assert 312**2-4*7392*7==-109632
report={'status':'PASS','bound':'L5 >= 12 v2','quadrupole_determinant_identity':True,'normalization_quartic':str(P),'quadratic_discriminant':-109632}
Path(__file__).with_name('quadrupole_burg_bound_verification.json').write_text(json.dumps(report,indent=2));print(report)
