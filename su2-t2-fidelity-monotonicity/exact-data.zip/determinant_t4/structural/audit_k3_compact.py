"""Supplementary independent audit of the two compact K=3 certificates.
Checks the new sharp-envelope comparisons with rational bisection roots,
a separate logarithm enclosure, explicit local positive-map matrices,
and exact domain coverage by a dyadic tree.
The general saved-certificate verifier is run separately for every leaf predicate.
"""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
import json,sympy as s
from sympy.physics.wigner import clebsch_gordan
ROOT=Path(__file__).parent.parent;C=(F(2,5),F(2,7),F(1,2),F(18,35))
ms=[2,1,0,-1,-2]
def T(l,q):return s.Matrix([[s.sqrt(s.Rational(2*l+1,5))*clebsch_gordan(2,l,2,m,q,n) for m in ms] for n in ms])
U=s.zeros(5);Jp=s.zeros(5)
for i in range(5):U[i,4-i]=(-1)**i
for i in range(1,5):Jp[i-1,i]=s.sqrt(i*(5-i))
A3=s.zeros(5)
for i,x in enumerate([1,2*s.sqrt(6)/5,2*s.sqrt(6)/5,1]):A3[i,i+1]=x
As=[Jp/s.sqrt(6),s.diag(1,1,0,-1,-1),A3]
expected=[(s.Rational(2,3),0),(s.Rational(18,25),s.Rational(2,25)),(s.Rational(484,625),s.Rational(6,625))]
for A,wanted in zip(As,expected):
 V=A*U;assert V.T==-V
 assert all(e>=0 for e in (s.eye(5)-A.conjugate().T*A).eigenvals())
 norms=[]
 for l in range(5):
  coeff=[s.trace(T(l,q).conjugate().T*A) for q in range(-l,l+1)]
  norms.append(s.simplify(sum(s.conjugate(z)*z for z in coeff)/5))
 assert norms[0]==norms[2]==norms[4]==0 and (norms[1],norms[3])==wanted

def root_bounds(z):
 assert z>=0
 if not z:return F(0),F(0)
 a=F(0);b=F(1)
 while b*b<z:b*=2
 for _ in range(60):
  m=(a+b)/2
  if m*m<=z:a=m
  else:b=m
 assert a*a<=z<=b*b
 return a,b

def ln_bounds(z):
 assert z>0
 if z<1:
  a,b=ln_bounds(1/z);return -b,-a
 count=0
 while z>=2:z/=2;count+=1
 def series(z):
  r=(z-1)/(z+1);val=F(0);term=r
  for k in range(20):val+=2*term/F(2*k+1);term*=r*r
  return val,val+2*term/(F(41)*(1-r*r))
 a,b=series(z);c,d=series(F(2));return a+count*c,b+count*d

def envelope(m,v):
 if v>=F(4,5)*(1-5*m)**2:return ln_bounds(1/(3125*m**4*(1-4*m)))[1]
 if not v:return F(0)
 candidates=[]
 for k in range(4):
  n=5-k;S=1-k*m;P=F(1,5)+v-k*m*m;D=n*P-S*S
  if D<0:continue
  rlo,rhi=root_bounds((n-1)*D)
  if (S-rlo)/n<m:continue
  b=max(m,(S-rhi)/n);rlo,rhi=root_bounds(D/F(n-1));a=max(m,(S+rlo)/n)
  candidates.append(ln_bounds(1/(3125*m**k*b*a**(n-1)))[1])
 assert candidates
 return max(candidates)

reports=[]
for N,cap in [(5,F(31,32)),(6,F(511,512))]:
 path=ROOT/'bounds'/f'compact_norm_floor_certificate_N{N}_K3.json';d=json.loads(path.read_text())
 assert d['complete'] and d['queue_remaining']==0 and F(d['quad_cap'])==cap
 assert tuple(map(F,d['c2']))==C
 full=tuple(map(F,d['amax']));f=tuple(map(F,d['f']));columns=[tuple(map(F,v)) for v in d['positive_columns']]
 assert full[1]==F(2,7)*cap
 bases=[]
 for rec in d['bases']:
  a=[F(0)]*4;res=[F(0)]*4;weight=F(0)
  for i,w in zip(rec['indices'],map(F,rec['weights'])):
   assert w>=0
   if i<len(columns):
    weight+=w
    for j in range(4):a[j]+=w*columns[i][j]
   else:
    j=(i-len(columns))%4;sgn=1 if i<len(columns)+4 else -1;a[j]+=sgn*w;res[j]+=w
  assert tuple(a)==f
  base=(F(1,5)-weight/5,tuple(-x for x in res));assert base==(F(rec['beta0']),tuple(map(F,rec['beta'])))
  bases.append(base)
 tree={};sharp=0;smallest=None
 for row in d['boxes']:
  lo=tuple(map(F,row['lo']));hi=tuple(map(F,row['hi']));node=tree
  # Recover the subdivision path by recursively locating the box inside the root.
  left=[F(0)]*4;right=list(full);depth=0
  while tuple(left)!=lo or tuple(right)!=hi:
   assert 'leaf' not in node
   axis=depth%4;mid=(left[axis]+right[axis])/2
   if hi[axis]<=mid:bit=0;right[axis]=mid
   elif lo[axis]>=mid:bit=1;left[axis]=mid
   else:raise AssertionError('Box does not follow the certified splitting order')
   node=node.setdefault(bit,{});depth+=1;assert depth<100
  assert not node;node['leaf']=True
  if row['kind']!='sharp_absolute':continue
  sharp+=1;vl=tuple(a*a/c for a,c in zip(lo,C));vh=tuple(a*a/c for a,c in zip(hi,C));rec=row['data']
  b0,bet=bases[rec['basis']];m=b0+sum(x*y for x,y in zip(bet,hi));assert 0<m<F(1,5)
  p1=F(5,2)*lo[0];p2=F(7,2)*lo[1];w=vl[0]+vl[2];x=F(rec['quad_x']);t=F(rec['odd_t'])
  assert 0<=p1<1 and 0<=p2<1 and 0<=w<F(1,2)
  assert 0<=x<1 and t>=0 and 2*w*t*t<1 and 2*w*t<1
  lower=max(ln_bounds((1-p1*p1/4)/(1-p1*p1)**4)[0],ln_bounds((1+p2/2)**2/((1-p2)**3*(1+p2)**4))[0],ln_bounds(1/(1-2*w)**4)[0],ln_bounds((1-x)**2*(1+x)*(1+x/2)**2/(1-x*p2)**5)[0],ln_bounds((1-2*w*t*t)/(1-2*w*t)**5)[0],F(25,3)*sum(vl),F(25,2)*vl[0],12*vl[1],12*w)
  if sum(vl):
   aa=F(1,5)+root_bounds(F(4,5)*sum(vl))[0]
   lower=max(lower,ln_bounds(256/(3125*aa*(1-aa)**4))[0])
  upper=envelope(m,sum(a*a*b for a,b in zip(f,vh)));gap=lower-upper
  assert gap>=0
  smallest=gap if smallest is None else min(smallest,gap)
 def covered(node):
  if 'leaf' in node:assert node=={'leaf':True}
  else:assert set(node)=={0,1};covered(node[0]);covered(node[1])
 covered(tree)
 report={'N':N,'K':3,'cap':str(cap),'leaves':len(d['boxes']),'independently_recomputed_sharp_leaves':sharp,'minimum_recomputed_gap_approx':float(smallest),'status':'PASS'}
 reports.append(report);print(report,flush=True)
out={'status':'PASS','explicit_BH_positive_map_checks':True,'sharp_envelope_mathematical_audit':'PASS','certificates':reports}
Path(__file__).with_name('k3_compact_audit.json').write_text(json.dumps(out,indent=2))
