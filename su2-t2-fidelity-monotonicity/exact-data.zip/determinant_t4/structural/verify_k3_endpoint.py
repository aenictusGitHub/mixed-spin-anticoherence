from pathlib import Path
from fractions import Fraction as F
from math import factorial
import sympy as s,json
from sympy.physics.wigner import wigner_6j,clebsch_gordan

def f(N,K,l):
 D=s.Integer(N*(N+2));u=s.Integer(K*(K+1))
 return s.factor(sum((-1)**r*s.prod((l*(l+1)-a*(a+1))*(u-a*(a+1)) for a in range(r))/(s.factorial(r)**2*s.prod(D-a*(a+2) for a in range(r))) for r in range(l+1)))
def G(N,q,l):
 j=s.Rational(N,2);b0=j-2
 return s.simplify((-1)**q*wigner_6j(2,2,l,j,j,b0+q)/wigner_6j(2,2,l,j,j,b0))
cases={5:(s.Rational(4,63),[s.Rational(4,105),0,s.Rational(29,45)],s.Rational(2,9)),6:(s.Rational(1,45),[s.Rational(1,75),s.Rational(19,45),s.Rational(34,75)],s.Rational(7,90))}
purities={}
for N,(a,ws,r) in cases.items():
 assert 5*a+sum(ws)==1
 assert r*s.Rational(2,7)==a
 for l in range(1,5):assert s.factor(sum(w*G(N,q,l) for q,w in enumerate(ws))-(r if l==2 else 0)-f(N,3,l))==0
 j=s.Rational(N,2)
 al=[s.Rational(N+1,5)*(clebsch_gordan(2,l,2,2,0,2)/clebsch_gordan(j,l,j,j,0,j))**2 for l in range(5)]
 vals=[]
 for J in range(N+1):
  if (N-J)%2:continue
  value=s.simplify(sum(al[l]*f(N,3,l)**2*(-1)**(N+J)*(2*l+1)*wigner_6j(j,j,l,j,j,J) for l in range(5)))
  vals.append((J,value))
 target=s.Rational(6739,22050) if N==5 else s.Rational(1,3)
 assert max(v for J,v in vals)==target
 purities[N]=[(J,str(v)) for J,v in vals]
c=F(1606,795);assert F(14,5)-F(124,159)==c
assert sum(F(7,10)**k/factorial(k) for k in range(4))-2==F(13,6000)>0
assert sum(F(4,3)**k/factorial(k) for k in range(5))-F(2304,625)==F(9503,151875)>0
A5=F(4658,2205)*F(504,499)**2;b5=F(907,3125)+F(4,503)
A6=F(8,3)*F(9216,9215)**2;b6=F(4,3)+F(4,46079)
assert A5<3 and A6<3
m5=(3-A5)*F(10,3)-A5*b5-c;m6=(3-A6)*F(52,3)-A6*b6-c
assert m5==F(47878982324888,311161765265625)>0
assert m6==F(118867231880642,622143902352225)>0
assert sum(F(15,4)**k/factorial(k) for k in range(9))-F(5184,125)==F(3077585521,7340032000)>0
m6new=F(6)-F(15,4)-c;assert m6new==F(731,3180)>0
mm=s.symbols('m',real=True)
assert s.expand((s.Rational(1,4)-2*mm)**2-(8*mm-20*mm**2))==24*mm**2-9*mm+s.Rational(1,16)
assert F(1,16)-F(9,400)>0
assert -F(1,3)+F(6,400)<0
assert (1-F(4,400))**2>F(1,3)
out={'status':'PASS','N5_delta_max':'1/32','N6_delta_max':'1/512','N5_Burg_gap':str(m5),'N6_Burg_gap':str(m6new),'independent_purity_spectra':purities,'exact_multiplier_decompositions':True}
Path(__file__).with_name('k3_endpoint_verification.json').write_text(json.dumps(out,indent=2));print(out)
