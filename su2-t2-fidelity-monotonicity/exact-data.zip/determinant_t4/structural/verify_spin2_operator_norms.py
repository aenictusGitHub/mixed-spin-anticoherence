from pathlib import Path
import sympy as s,json
from sympy.physics.wigner import wigner_6j
fierz=[]
for J in range(5):
 q2=(-1)**J*5*wigner_6j(2,2,2,2,2,J);q1=(-1)**J*3*wigner_6j(2,2,1,2,2,J)
 fierz.append(s.simplify(q2-s.Rational(5,7)*q1-(s.Rational(10,7) if J==0 else 0)))
assert fierz==[0,s.Rational(6,7),0,-s.Rational(4,7),0]
Jp=s.zeros(5)
for k in range(1,5):Jp[k-1,k]=s.sqrt(k*(5-k))
Jx=(Jp+Jp.T)/2;Jy=(Jp-Jp.T)/(2*s.I);Jz=s.diag(2,1,0,-1,-2)
u=s.eye(5)[:,2];v=(s.eye(5)[:,0]+s.eye(5)[:,4])/s.sqrt(2);X=s.I*(u*v.T-v*u.T)/s.sqrt(2)
assert s.trace(X*X)==1
assert all(s.trace(X*J)==0 for J in [Jx,Jy,Jz])
assert X.eigenvals()=={0:3,-s.sqrt(2)/2:1,s.sqrt(2)/2:1}
out={'fierz_eigenvalues':[str(x) for x in fierz],'rank3_sharpness_verified':True,'sharp_c_squared':['2/5','2/7','1/2','18/35']}
Path(__file__).with_name('spin2_operator_norms_verification.json').write_text(json.dumps(out,indent=2));print(out)
