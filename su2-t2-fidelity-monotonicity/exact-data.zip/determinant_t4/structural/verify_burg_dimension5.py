from pathlib import Path
from fractions import Fraction as F
import json,sympy as s
r=F(13,19);gap=2*sum((r**(2*k+1)/F(2*k+1) for k in range(5)),F(0))-F(5,3);assert gap>0
a=s.symbols('a',positive=True)
fun=-s.log(s.Rational(3125,256)*a*(1-a)**4)-s.Rational(125,12)*(a-s.Rational(1,5))**2
assert s.simplify(s.diff(fun,a)-(5*a-1)*(1/(a*(1-a))-s.Rational(25,6)))==0
assert s.simplify(fun.subs(a,s.Rational(3,5))-(s.log(s.Rational(16,3))-s.Rational(5,3)))==0
out={'global_lower_constant':'25/3','positive_log_gap_certificate':str(gap),'gap_decimal':float(gap),'symbolic_derivative_and_stationary_value_verified':True}
Path(__file__).with_name('burg_dimension5_verification.json').write_text(json.dumps(out,indent=2));print(out)
