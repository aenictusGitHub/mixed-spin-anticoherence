"""Independent exact audit of the order-four finite reduction.
Reads the saved certificates without importing their generation scripts.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from math import comb,gcd,lcm
from functools import reduce
import json,time
import sympy as s
from sympy.physics.wigner import wigner_6j,clebsch_gordan
B=Path(__file__).parent.parent/'bounds'
H=json.loads((B/'exact_hull.json').read_text())
C=json.loads((B/'continuous_hull_N12.json').read_text())
S=json.loads((B/'small_case_certificates.json').read_text())
V=[[F(x) for x in row] for row in H['vertices']]
def f(N,K,l):
 D=F(N*(N+2));u=F(K*(K+1));ans=F(1)
 for r in range(1,l+1):
  top=F((-1)**r);bot=F(1)
  for a in range(r):top*= (l*(l+1)-a*(a+1))*(u-a*(a+1));bot*=(a+1)**2*(D-a*(a+2))
  ans+=top/bot
 return ans
def point(source):
 N,K,z=source
 return [f(N,K,l)*(z if l%2 else 1) for l in range(1,5)]
assert all(v==point(src) for v,src in zip(V,H['sources']))
# Independent 6j multipliers for every finite source and a larger spin.
for N in list(range(4,12))+[12,17]:
 for K in range(N+1):
  for ell in range(1,5):
   r=(-1)**(N+K+ell)*(N+1)*wigner_6j(s.Rational(N,2),s.Rational(N,2),K,s.Rational(N,2),s.Rational(N,2),ell)
   assert s.Rational(f(N,K,ell))==r,(N,K,ell)
for row in H['omitted_vertex_decompositions']:
 w=list(map(F,row['weights']));ids=row['support'];assert min(w)>=0 and sum(w)==1
 assert [sum(a*V[i][l] for i,a in zip(ids,w)) for l in range(4)]==point(row['source'])
# Ensure no original source omitted from the certificate accounting.
original={tuple(point((N,K,z))) for N in range(4,12) for K in range(N+1) for z in [1,-1]}
accounted={tuple(v) for v in V}|{tuple(point(r['source'])) for r in H['omitted_vertex_decompositions']}
assert original==accounted
rows=[]
for v in V:
 d=lcm(*(q.denominator for q in v));rows.append(tuple([int(q*d) for q in v]+[d]))
assert s.Matrix(rows).rank()==5
def determinant4(a):
 # Independent permutation formula.
 from itertools import permutations
 total=0
 for p in permutations(range(4)):
  z=(-1)**sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))
  for i in range(4):z*=a[i][p[i]]
  total+=z
 return total
found=set()
for ids in combinations(range(len(rows)),4):
 R=[rows[i] for i in ids]
 norm=tuple((-1)**j*determinant4([r[:j]+r[j+1:] for r in R]) for j in range(5))
 if not any(norm):continue
 signs={1 if z>0 else -1 for row in rows if (z:=sum(x*y for x,y in zip(row,norm)))}
 if len(signs)!=1:continue
 sign=next(iter(signs));g=reduce(gcd,map(abs,norm));found.add(tuple(sign*x//g for x in norm))
assert found==set(map(tuple,H['facets']))
print('Finite hull: all 161 facets independently enumerated.',flush=True)
# Recover the five coherent-state probability facets from the normalized tensors.
f1,f2,f3,f4=s.symbols('f1 f2 f3 f4');fv=[s.Integer(1),f1,f2,f3,f4]
T=[]
for ell in range(5):
 T.append([s.sqrt(s.Rational(2*ell+1,5))*clebsch_gordan(2,ell,2,m,0,m) for m in [2,1,0,-1,-2]])
coherent=set()
for i in range(5):
 p=s.expand(sum(fv[l]*T[l][0]*T[l][i] for l in range(5)))
 nums=[p.coeff(x) for x in [f1,f2,f3,f4]]+[p.subs({f1:0,f2:0,f3:0,f4:0})]
 d=s.ilcm(*[q.q for q in nums]);nums=[int(d*q) for q in nums];g=reduce(gcd,map(abs,nums));coherent.add(tuple(q//g for q in nums))
assert coherent.issubset(found) and len(coherent)==5
# Reconstruct every polynomial from the multiplier formulas, rather than trust saved basis.
Y,Z=s.symbols('Y Z');y=Y/14;D=(1-2*y)/y**2
x=-1+2*y+2*(1-6*y)*(1+3*y)*Z/(1-2*y);u=D*(1-x)/2
Q=8*(1-3*y)*(1+y)*(1-4*y)*(1+2*y)*(1-5*y)*(1+3*y)*(1-2*y)**4
basis=[]
for ell in range(1,5):
 e=s.Integer(1)
 for r in range(1,ell+1):
  top=(-1)**r*s.prod((ell*(ell+1)-a*(a+1))*(u-a*(a+1)) for a in range(r))
  bot=s.factorial(r)**2*s.prod(D-a*(a+2) for a in range(r));e+=top/bot
 basis.append(s.Poly(s.cancel(Q*e),Y,Z))
basis.append(s.Poly(s.cancel(Q),Y,Z))
assert all(s.expand(p.as_expr()-s.sympify(q))==0 for p,q in zip(basis,C['polynomial_basis']))
assert C['Nmin']==12 and C['Kmin']==4 and C['failed']==[]
assert set(tuple(z['facet']) for z in C['certificates'])==found-coherent
n,m=C['degree'];assert [n,m]==[11,4]
power=[{ij:F(c) for ij,c in p.terms()} for p in basis]
def box_coefficients(poly,a,b,c,d):
 # Affine expansion in each coordinate followed by the direct power-to-Bernstein identity.
 scaleY=b-a;scaleZ=d-c
 affine={}
 for (i,j),v in poly.items():
  for h in range(i+1):
   for k in range(j+1):
    affine[h,k]=affine.get((h,k),F(0))+v*comb(i,h)*a**(i-h)*scaleY**h*comb(j,k)*c**(j-k)*scaleZ**k
 return [sum(v*F(comb(h,i),comb(n,i))*F(comb(k,j),comb(m,j)) for (i,j),v in affine.items() if i<=h and j<=k) for h in range(n+1) for k in range(m+1)]
count=0;t0=time.time()
for rec in C['certificates']:
 facet=rec['facet'];poly={}
 for r,p in zip(facet,power):
  for ij,v in p.items():poly[ij]=poly.get(ij,F(0))+r*v
 poly={ij:v for ij,v in poly.items() if v}
 boxes=[list(map(F,z)) for z in rec['boxes']]
 assert sum((b-a)*(d-c) for a,b,c,d,_ in boxes)==1
 for a,b,c,d,_ in boxes:assert 0<=a<b<=1 and 0<=c<d<=1
 for A,Bx in combinations(boxes,2):
  assert min(A[1],Bx[1])<=max(A[0],Bx[0]) or min(A[3],Bx[3])<=max(A[2],Bx[2])
 for a,b,c,d,saved in boxes:
  cs=box_coefficients(poly,a,b,c,d);assert min(cs)==saved and min(cs)>=0;count+=1
 if count//200!=(count-len(boxes))//200:print('Direct Bernstein audit',count,'boxes',round(time.time()-t0,1),'seconds',flush=True)
print('All',count,'rational boxes independently verified.',flush=True)
# Available-extension decomposition certificates.
expected={(N,K) for N in range(5,12) for K in range(N+1)}
assert {(r['N'],r['K']) for r in S['small_spins']}==expected
bases={tuple(v) for v in S['base_cases']}
assert len(bases)==14
for row in S['small_spins']:
 N,K=row['N'],row['K'];components=row['components'];w=[F(c['weight']) for c in components]
 assert min(w)>=0 and sum(w)==1
 for c in components:
  M,k,z=c['source'];assert M<=N and (M==4 or (M,k) in bases) and z in [-1,1]
 assert [sum(q*point(c['source'])[l] for q,c in zip(w,components)) for l in range(4)]==[f(N,K,l) for l in range(1,5)]
DD,z=s.symbols('D z')
for Ks,weights in S['small_K_coefficients'].items():
 K=int(Ks);w=[s.sympify(q) for q in weights];assert s.factor(sum(w)-1)==0
 for q in w:
  num,den=s.fraction(q)
  assert all(c>=0 for c in s.Poly(s.expand(num.subs(DD,168+z)),z).all_coeffs())
  assert all(c>=0 for c in s.Poly(s.expand(den.subs(DD,168+z)),z).all_coeffs()) and den.subs(DD,168)>0
 for ell in range(1,5):
  target=1
  for r in range(1,ell+1):
   target+=(-1)**r*s.prod((ell*(ell+1)-a*(a+1))*(K*(K+1)-a*(a+1)) for a in range(r))/(s.factorial(r)**2*s.prod(DD-a*(a+2) for a in range(r)))
  assert s.factor(sum(q*s.Rational(f(4,k,ell)) for k,q in enumerate(w))-target)==0
report={'status':'PASS','facets':len(found),'bernstein_boxes':count,'finite_spins_vertices':len(expected),'base_cases':len(bases),'coherent_facets':[list(x) for x in sorted(coherent)],'independent_6j_checks':True}
Path(__file__).with_name('finite_reduction_audit.json').write_text(json.dumps(report,indent=2));print(report)
