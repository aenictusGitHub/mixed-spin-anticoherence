# Order five: entropy gain implies fidelity gain

Let ρ be a density matrix on spin N/2, N≥5, and Φ an SU(2)-covariant channel on that irreducible spin space. Let σ=ρ₅ and τ=(Φρ)₅. Write T(X)=Tr√X and use natural logarithms for the von Neumann entropy S(X). Then

    T(τ)−T(σ) ≥ [S(τ)−S(σ)]/400.

In particular, a strictly positive entropy gain implies a strictly positive fidelity gain at the same input. For the manuscript's A₅=(T²−1)/5, a nonnegative entropy gain implies ΔA₅ ≥ ΔS/1000.

## Verification

Run `python3 verify.py` with Python 3 and assertions enabled. Only the standard library is required. The checker reconstructs five integer sextics, checks a complete decomposition of the nonnegative orthant for each, and verifies the auxiliary linear inequality below. The subdivision choices in cones.json can be arbitrary. Soundness follows from checking every terminal polynomial coefficient and requiring both children of each internal node. The run record is in verification.txt.

The physical inputs to the proof are the multiplier hull with available extensions, the lower eigenvalue and upper purity bounds, and the residual decompositions established in the project's [order-five proof](https://github.com/aenictusGitHub/mixed-spin-anticoherence/blob/main/su2-order-five-monotonicity/proof.tex), Sections 2, 4, 4.1 and 5. The scalar part below replaces the original fidelity-only spectral test. No entropy or fidelity monotonicity on earlier vertices is invoked to establish the quantitative comparison.

## Spectral estimate

Let z₀≤⋯≤z₅ be the square roots of the six input eigenvalues. To keep all polynomials homogeneous, set s=Σzᵢ², w=Σzᵢ, p=Σzᵢ⁴ and j=Σ(2i−5)zᵢ². Normalized states have s=1. Each row below gives a lower bound k² on every output eigenvalue and an upper bound Q on output purity, where

    k=(K₀z₀+K₁z₁+K₂z₂)/M,   Q=(a s² + b p + c j²)/D.

| Row | Cases | M | (K₀,K₁,K₂) | D | (a,b,c) | Verified cones |
|---|---|---:|---|---:|---|---:|
| common | (6,3), (6,4), (6,5), and every normalized residual of positive mass | 100 | (31,0,0) | 8 | (1,2,0) | 15 |
| 62 | (6,2), (8,3) | 10000 | (3433,2203,1270) | 224 | (28,56,1) | 297 |
| 73 | (7,3) | 2000 | (456,209,95) | 12000 | (1612,2328,33) | 639 |
| 74 | (7,4) | 100 | (24,0,0) | 15 | (2,3,0) | 6 |
| 75 | (7,5), (7,6), (8,6), (8,7) | 100 | (63,0,0) | 1323 | (160,363,0) | 5 |

Define L=(s−kw)²(s−6k²)−(Q−k²s)(w−6k)². The certified inequality is

    L ≥ (3/100) s (p−s²/6).

To check it, take g₀=z₀ and gᵢ=zᵢ−zᵢ₋₁ for i≥1. The checker expands 200 D M⁴ times the difference of the two sides as a degree-six polynomial in the nonnegative g. Splitting on gᵢ≥gⱼ or its reverse covers the parent orthant. For the first branch the substitution gᵢ=hᵢ+hⱼ/2, gⱼ=hⱼ/2 parametrizes exactly that half. The second branch exchanges i and j. Multiplying each child polynomial by 2⁶ clears its denominators, so all checks use integers. The 962 final cones have nonnegative coefficients, including all their boundary faces.

For normalized inputs w−5k≥1. Indeed the step-vector expansion of z gives ||z||₂≤Σⱼ√(6−j) gⱼ by the triangle inequality. The coefficient of gⱼ in w−5k is 6−j−5Σᵢ≥ⱼKᵢ/M. The checker verifies that each coefficient is nonnegative and its square is at least 6−j. Also k≤(ΣKᵢ/M)w/6<w/6, since the padded coefficients Kᵢ are decreasing and zᵢ are increasing. Thus w−6k>0, kw<1, and 6k²<1.

Put l=(1−kw)/(w−6k). Since w≥1 and w−5k≥1, we have w−6k≥1−k≥1−kw, whence 0<l≤1. For each output eigenvalue y and x=√y≥k, expand the nonnegative product (x−k)(x−l)²(x+k+2l). Summing over all six eigenvalues, using their trace one and purity ≤Q, gives

    2l(k+l)² [T(output)−w] ≥ l²(1−6k²)+k²−Q = L/(w−6k)².

Here the terms proportional to 1−kw−l(w−6k) cancel exactly. Since (k+l)(w−6k)=1−6k², the trace gain is at least L/[2l(1−6k²)²] ≥ L/2. Consequently

    T(output)−T(σ) ≥ (3/200) V(σ),    V(σ)=Tr σ²−1/6.

This estimate applies specifically to the eleven direct vertices and the positive-mass normalized residuals. It includes singular spectra.

## Passing to every channel

For any output the elementary bound ΔS≤log 6−S(σ)≤6V(σ) follows from log x≤x−1. Hence each of the preceding spectral comparisons increases J(X)=T(X)−S(X)/400.

The scalar summand √x + x log(x)/400 is concave on [0,1], with its continuous value at zero. Its trace sum J is therefore concave and Schur-concave. Local positive unital trace-preserving maps increase J by majorization; spin reversal preserves it. In the remaining 23 generator decompositions, the normalized residual of positive mass satisfies the common spectral row. The other terms are local or were treated at smaller parent spin. Induction on that spin and concavity of J establish the comparison for all 34 physical generators. The case with zero residual mass uses concavity directly. The project's available-extension hull then gives the claim for all Φ and N>5. At N=5 the marginal is the entire state, and irreducible covariance implies unitality, so majorization again gives the comparison.

## Equality

Under the entropy hypothesis applied to all inputs, the comparison gives nonnegative trace-root gains at all depolarized inputs. Thus d(u)=Tr√(τ+uI)−Tr√(σ+uI) is nonnegative for u≥0. The [project's entropy identity](https://github.com/aenictusGitHub/mixed-spin-anticoherence/blob/main/fidelity-implies-entropy/proof.tex#L42-L56) gives ΔS=2∫₀^∞d(u)du/√u. If ΔS=0, continuity forces d(u)=0 for every u. Expanding at large u gives equality of all power sums, hence of the two spectra. Conversely equal spectra give both gains zero, and zero fidelity gain forces ΔS=0 by the quantitative comparison and the entropy hypothesis.
