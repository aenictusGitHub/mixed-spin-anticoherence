"""Exact order-five entropy/fidelity gain certificate. Run with Python 3."""
import json
from collections import defaultdict
from fractions import Fraction
from math import comb
from pathlib import Path

# k = sum K_i z_i / M.  Q = (a S^2 + b P + c J^2)/D.
ROWS = {
    'common': (100, (31,), 8, 1, 2, 0),
    '62': (10000, (3433, 2203, 1270), 224, 28, 56, 1),
    '73': (2000, (456, 209, 95), 12000, 1612, 2328, 33),
    '74': (100, (24,), 15, 2, 3, 0),
    '75': (100, (63,), 1323, 160, 363, 0),
}

def add(*polynomials):
    result = defaultdict(int)
    for polynomial in polynomials:
        for powers, coefficient in polynomial.items():
            result[powers] += coefficient
    return {powers: value for powers,value in result.items() if value}

def scale(constant, polynomial):
    return {powers: constant*value for powers,value in polynomial.items() if constant*value}

def multiply(left, right):
    result = defaultdict(int)
    for p,a in left.items():
        for q,b in right.items():
            powers = tuple(x+y for x,y in zip(p,q))
            result[powers] += a*b
    return {powers: value for powers,value in result.items() if value}

def square(polynomial):
    return multiply(polynomial,polynomial)

def comparison(row):
    M,weights,D,a,b,c = row
    gaps = [{tuple(int(i==j) for j in range(6)): 1} for i in range(6)]
    z = [add(*gaps[:i+1]) for i in range(6)]
    x = list(map(square,z))
    S,W,P = add(*x), add(*z), add(*map(square,x))
    J = add(*(scale(2*i-5,p) for i,p in enumerate(x)))
    K = add(*(scale(w,p) for w,p in zip(weights,z)))
    cap = add(scale(a,square(S)),scale(b,P),scale(c,square(J)))
    # The first difference is D M^4 L, with L defined in README.md.
    left = multiply(square(add(scale(M,S),scale(-1,multiply(K,W)))),
                    add(scale(M*M,S),scale(-6,square(K))))
    right = multiply(add(scale(M*M,cap),scale(-D,multiply(square(K),S))),
                     square(add(scale(M,W),scale(-6,K))))
    physical_sextic = add(scale(D,left),scale(-1,right))
    six_variance = add(scale(6,P),scale(-1,square(S)))
    # 200 D M^4 [L - (3/100) S (P-S^2/6)].
    return add(scale(200,physical_sextic),scale(-D*M**4,multiply(S,six_variance)))

def midpoint_child(polynomial,i,j):
    # Substitute g_i=h_i+h_j/2, g_j=h_j/2, and multiply the whole
    # degree-six polynomial by 2^6. All coordinates except i,j are unchanged.
    result = defaultdict(int)
    for powers,value in polynomial.items():
        degree_i,degree_j = powers[i],powers[j]
        assert sum(powers)==6
        for moved in range(degree_i+1):
            new_powers = list(powers)
            new_powers[i] -= moved
            new_powers[j] += moved
            result[tuple(new_powers)] += (value*comb(degree_i,moved)
                                         * 2**(6-degree_j-moved))
    return {powers: value for powers,value in result.items() if value}

def check_tree(tokens, polynomial):
    node = next(tokens)
    if node=='.':
        assert all(value>=0 for value in polynomial.values()), 'Negative power coefficient'
        return 1
    i,j = divmod(ord(node)-ord('A'),6)
    assert 0<=i<j<6
    return (check_tree(tokens,midpoint_child(polynomial,i,j))
            + check_tree(tokens,midpoint_child(polynomial,j,i)))

def check_linear_bound(row):
    M,weights,*_ = row
    assert all(x>=0 for x in weights) and sum(weights)<M
    assert list(weights)==sorted(weights,reverse=True)
    # Triangle inequality ||z||_2 <= sum_j sqrt(6-j) g_j.
    # Compare each coefficient of W-5k with sqrt(6-j).
    for j in range(6):
        coefficient = 6-j-5*Fraction(sum(weights[j:]),M)
        assert coefficient>=0 and coefficient**2>=6-j

def main():
    if not __debug__:
        raise RuntimeError("Use Python without -O so the proof checks are enabled.")
    trees=json.loads(Path(__file__).with_name('cones.json').read_text())
    assert set(trees)==set(ROWS)
    total=0
    for name,row in ROWS.items():
        check_linear_bound(row)
        tokens=iter(trees[name])
        leaves=check_tree(tokens,comparison(row))
        assert next(tokens,None) is None
        print(f'{name}: {leaves} cones verified',flush=True)
        total+=leaves
    print(f'Total: {total} cones verified')

if __name__=='__main__':
    main()
