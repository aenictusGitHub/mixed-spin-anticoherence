"""Exact sextic positivity on cones of sorted input eigenvalue square roots.

The coordinate g_i is z_i - z_(i-1), with g_0=z_0. Each cone split compares
two g coordinates. The child substitutions g_i <- g_i+g_j and its reverse
cover the whole parent cone. Nonnegative power coefficients prove each leaf.
"""
import json
from collections import defaultdict
from fractions import Fraction
from math import comb
from pathlib import Path

from model import square as multipliers, vector


def add(*terms):
    total = defaultdict(int)
    for term in terms:
        for variable, value in term.items():
            total[variable] += value
    return {m: v for m, v in total.items() if v}


def scale(c, p):
    return {m: c*v for m, v in p.items() if c*v}


def multiply(p, q):
    result = defaultdict(int)
    for u, a in p.items():
        for v, b in q.items():
            result[tuple(m+n for m, n in zip(u, v))] += a*b
    return {m: v for m, v in result.items() if v}


def square(p):
    return multiply(p, p)


# M, K coefficients, D, a, b, c.
# k = K.z/M. Q = (aS² + b sum z_i^4 + c (sum (2i-5) z_i²)^2)/D.
PARAMETERS = {
    "common": (100, (31,), 8, 1, 2, 0),
    "62": (10000, (3433, 2203, 1270), 224, 28, 56, 1),
    "73": (2000, (456, 209, 95), 12000, 1612, 2328, 33),
    "74": (100, (24,), 15, 2, 3, 0),
    "75": (100, (63,), 1323, 160, 363, 0),
}


def sextic(parameters):
    M, coefficients, D, a, b, c = parameters
    g = [{tuple(int(i == j) for j in range(6)): 1} for i in range(6)]
    z = [add(*g[:i+1]) for i in range(6)]
    x = [square(t) for t in z]
    S, W = add(*x), add(*z)
    K = add(*(scale(w, t) for w, t in zip(coefficients, z)))
    A = add(*(scale(2*i-5, t) for i, t in enumerate(x)))
    q = add(scale(a, square(S)), scale(b, add(*(square(t) for t in x))),
            scale(c, square(A)))
    lhs = multiply(square(add(scale(M, S), scale(-1, multiply(K, W)))),
                   add(scale(M*M, S), scale(-6, square(K))))
    rhs = multiply(add(scale(M*M, q), scale(-D, multiply(square(K), S))),
                   square(add(scale(M, W), scale(-6, K))))
    return add(scale(D, lhs), scale(-1, rhs))


def sheared(p, i, j):
    transformed = defaultdict(int)
    for monomial, value in p.items():
        for power in range(monomial[i]+1):
            m = list(monomial)
            m[i] -= power
            m[j] += power
            transformed[tuple(m)] += value*comb(monomial[i], power)
    return transformed


def tree_check(tokens, p):
    token = next(tokens)
    if token == ".":
        assert all(c >= 0 for c in p.values())
        return 1
    i, j = divmod(ord(token)-65, 6)
    assert 0 <= i < j < 6
    return tree_check(tokens, sheared(p, i, j)) + tree_check(tokens, sheared(p, j, i))


def check_channel_bounds():
    """Check every coefficient converting the physical estimates into table rows."""
    F = Fraction
    r = F(1, 6)
    groups = {
        "common": [(6, 3), (6, 4), (6, 5)],
        "62": [(6, 2), (8, 3)],
        "73": [(7, 3)],
        "74": [(7, 4)],
        "75": [(7, 5), (7, 6), (8, 6), (8, 7)],
    }
    simple_relative = {"common": F(7, 72), "74": F(2, 33), "75": F(3969, 10000)}
    for name, seeds in groups.items():
        M, K, D, a, b, c = PARAMETERS[name]
        # Q=r+B*(p-r)+G*J², with J twice the sorted magnetic expectation.
        B, G = F(b, D), F(c, D)
        assert F(a,D) == r*(1-B)
        for n, k in seeds:
            f = multipliers(n, k)
            assert max(t*t for t in f[1:]) <= B
            assert max(F(0), f[0]**2-B)*F(2,35)/4 <= G
        if name in simple_relative:
            assert F(K[0], M)**2 <= simple_relative[name]
    for label, eta, beta1, beta2 in (
        ("62", F(14,27), F(38858,100000), F(10410,100000)),
        ("73", F(8,55), F(2,5), F(1,8)),
    ):
        j, s = (2, F(451,1225)) if label=="62" else (3, F(79,210))
        for rank, beta in [(1,beta1),(2,beta2)]:
            center = 1-rank*r-beta
            assert center >= 0 and center**2 >= (rank-rank**2*r)*(s-r)
        M, K, *_ = PARAMETERS[label]
        h = (eta*(1-beta1),eta*(beta1-beta2),eta*beta2)
        assert sum(F(k,M)**2/hi for k,hi in zip(K,h)) <= 1
    assert F(20,33) >= F(14,27)
    assert min(F(7,20), F(7,33), F(7,72)) == F(7,72)

    # The last table row uses the local weight in a physical decomposition.
    floors = json.loads(Path(__file__).with_name("floors.json").read_text())
    bounds = {nk:simple_relative[name] for name in ("74","75") for nk in groups[name]}
    found = set()
    for entry in floors:
        pair = (entry["N"],entry["K"])
        if pair not in bounds:
            continue
        terms = [(label,F(w)) for label,w in entry["decompositions"][-1]]
        assert all(w >= 0 and label[0] in ("local","rect") for label,w in terms)
        assert sum(w for _,w in terms) == 1
        assert sum(w for label,w in terms if label[0]=="local") >= bounds[pair]
        assert tuple(sum(w*vector(label)[i] for label,w in terms) for i in range(5)) == multipliers(*pair)
        found.add(pair)
    assert found == set(bounds)

    # Self-adjoint local channels: the reflected-channel proof for U2, and
    # the squared multiplier bound on the five nonconstant ranks for U3.
    s2 = F(451,1225)
    weights = (F(1147,14700),F(33,196),F(65,147),0,F(2451,4900),F(99,4900))
    assert all(w>=0 for w in weights) and sum(weights)==6*s2-1
    for l in range(1,6):
        assert sum(w*(-1)**l*multipliers(5,j)[l-1] for j,w in enumerate(weights)) == -multipliers(5,2)[l-1]**2
    assert r+(1-r)*max(t*t for t in multipliers(5,3)) < F(79,210)


def main():
    if not __debug__:
        raise RuntimeError("Run with assertions enabled.")
    data = json.loads(Path(__file__).with_name("sextic_cones.json").read_text())
    assert set(data) == set(PARAMETERS)
    for name, expected in zip(PARAMETERS, (4, 41, 169, 2, 4)):
        tokens = iter(data[name])
        count = tree_check(tokens, sextic(PARAMETERS[name]))
        assert next(tokens, None) is None and count == expected
        print(f"{name}: {count} cones verified")
    check_channel_bounds()
    print("All 220 positivity cones verified.")


if __name__ == "__main__":
    main()
