"""Exact square and rectangular rank multipliers, with phase relative to R."""
from functools import lru_cache
from fractions import Fraction as F
from math import comb, factorial, prod

T = 5


@lru_cache(None)
def square(n,k):
    return tuple(sum((-1)**r * comb(l,r)*comb(l+r,r) *
                     prod(F((k-i)*(k+i+1),(n-i)*(n+i+2)) for i in range(r))
                     for r in range(min(k,l)+1)) for l in range(1,T+1))


@lru_cache(None)
def rectangular(n,q):
    """Ratio of the Racah sums for environment spin (n-t)/2+q and q=0."""
    def racah(l,q):
        lower = [T+l,n+q,n+q,n+l]
        upper = [T+n,n+l+q,n+l+q]
        total = sum(F((-1)**z * factorial(z+1),
                      prod(factorial(z-i) for i in lower)*prod(factorial(i-z) for i in upper))
                    for z in range(max(lower),min(upper)+1))
        return total*F(factorial(T-q)*factorial(q)*factorial(n-T+q),factorial(n+q+1))
    return tuple((-1)**q * racah(l,q)/racah(l,0) for l in range(1,T+1))


def vector(label):
    kind,n,k,flip = label
    if kind == 'depolarize':
        return (F(0),)*T
    v = square(n,k) if kind == 'local' else rectangular(n,k)
    return tuple(val*(-1)**((i+1)*flip) for i,val in enumerate(v))


def labels(n):
    yield ('depolarize',0,0,0)
    for k in range(T+1):
        for flip in (0,1):
            yield ('local',T,k,flip)
    for m in range(T+1,n+1):
        for k in range(T+1):
            for flip in (0,1):
                yield ('rect',m,k,flip)
